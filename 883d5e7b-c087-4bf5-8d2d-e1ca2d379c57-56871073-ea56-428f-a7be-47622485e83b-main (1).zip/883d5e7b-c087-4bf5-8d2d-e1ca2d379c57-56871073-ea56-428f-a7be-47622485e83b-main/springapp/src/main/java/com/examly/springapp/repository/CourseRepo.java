package com.examly.springapp.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.examly.springapp.model.Course;

import jakarta.transaction.Transactional;


@Repository   
public interface CourseRepo extends JpaRepository<Course, Long> {

    @Transactional
    @Modifying
    @Query("update Course c set c.courseType =?1 , c.courseDetails = ?2 , c.coursePrice = ?3 where c.courseId = ?4")
    public int updateCourse(String courseType, String courseDetails, Double coursePrice,Long courseId);
}

