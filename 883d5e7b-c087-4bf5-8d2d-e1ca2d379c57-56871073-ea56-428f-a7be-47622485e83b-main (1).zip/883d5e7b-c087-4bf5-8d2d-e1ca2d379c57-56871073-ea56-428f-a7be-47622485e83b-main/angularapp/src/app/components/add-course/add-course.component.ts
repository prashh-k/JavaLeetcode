import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CourseService } from 'src/app/services/course.service';

@Component({
  selector: 'app-add-course',
  templateUrl: './add-course.component.html',
  styleUrls: ['./add-course.component.css']
})
export class AddCourseComponent implements OnInit {

  file: File;
  fileName: string = '';
  isUploaded: boolean = false;
  isSuccess: boolean = false;
  courseForm: FormGroup;
  courses: string[] = [
    'Web Development', 'Mobile App Development', 'Data Science & Machine Learning', 'Cybersecurity', 'Artificial Inteligence(AI)', 'Finance & Accounting', 'Graphic Design', 'Marketing & Sales', 'Entrepreneurship', 'Networking', 'Communication Skills', 'Aptitude'
  ];

  constructor(private courseService: CourseService, private route: Router, private formBuilder: FormBuilder,
    private toastrService: ToastrService) {
    this.courseForm = formBuilder.group({
      courseType: ['', Validators.required],
      courseDetails: ['', Validators.required],
      coursePrice: ['', [Validators.required, Validators.min(0)]]
    });
  }


  onFileSelected(event) {
    this.file = event.target.files[0];
    if (this.file) {
      this.fileName = this.file.name;
      this.isUploaded = true;
      this.isSuccess = true;
    }
  }


  addCourse() {
    console.log(this.courseForm.value);

    let formData = new FormData();
    let course = {
      courseType: this.courseForm.value.courseType,
      courseDetails: this.courseForm.value.courseDetails,
      coursePrice: this.courseForm.value.coursePrice
    };

    let strCourse = JSON.stringify(course);
    formData.append("uploadFile", this.file);
    formData.append("course", strCourse);

    this.courseService.addCourse(formData).subscribe((data) => {
      this.toastrService.success("course added successfully");
      this.route.navigate(['/view-courses']);
    });
  }

  get f() {
    return this.courseForm.controls;
  }

  ngOnInit(): void {
  }
}

