package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.DTO.CustomerDTO;
import com.examly.springapp.model.Customer;
import com.examly.springapp.service.CustomerService;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {

    CustomerService customerService;

    @Autowired
    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @PostMapping
    public ResponseEntity<Customer> registerNewCustomer(@RequestBody CustomerDTO customerDto){
        Customer addedcustomer = customerService.addNewCustomer(customerDto);
        if(addedcustomer !=null){
            return ResponseEntity.status(201).body(addedcustomer);
        }
        return ResponseEntity.status(500).build();
    }

    @GetMapping("/{customerId}")
    public ResponseEntity<Customer> getCustomerByCustomerId (@PathVariable Long customerId){
        Customer customer = customerService.getCustomerByCustomerId(customerId);
        if(customer !=null){
            return ResponseEntity.status(200).body(customer);
        }
        return ResponseEntity.status(404).build();
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<Customer> getCustomerByUserId (@PathVariable Long userId){
        Customer customer = customerService.getCustomerByUserId(userId);
        if(customer !=null){
            return ResponseEntity.status(200).body(customer);
        }
        return ResponseEntity.status(404).build();
    }

    @GetMapping
    public ResponseEntity<List<Customer>> getAllCustomer (){
        List<Customer> customerList = customerService.getAllCustomers();
        if(customerList.isEmpty()){
            return ResponseEntity.status(404).build();
           
        }
        return ResponseEntity.status(200).body(customerList);
    }
}
