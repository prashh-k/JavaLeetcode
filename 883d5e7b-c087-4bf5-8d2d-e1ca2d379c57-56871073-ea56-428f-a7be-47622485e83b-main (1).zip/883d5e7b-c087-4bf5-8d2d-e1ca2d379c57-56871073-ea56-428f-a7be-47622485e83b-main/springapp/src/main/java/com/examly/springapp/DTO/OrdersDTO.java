
package com.examly.springapp.DTO;

import java.util.List;

public class OrdersDTO {
    double orderPrice;

    List<Long> courseIdList;
    Long customerId ;
    public OrdersDTO() {
    }
    public OrdersDTO(double orderPrice, List<Long> courseIdList, Long customerId) {
        this.orderPrice = orderPrice;
        this.courseIdList = courseIdList;
        this.customerId = customerId;
    }
    public double getOrderPrice() {
        return orderPrice;
    }
    public void setOrderPrice(double orderPrice) {
        this.orderPrice = orderPrice;
    }
    public List<Long> getCourseIdList() {
        return courseIdList;
    }
    public void setCourseIdList(List<Long> courseIdList) {
        this.courseIdList = courseIdList;
    }
    public Long getCustomerId() {
        return customerId;
    }
    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }
    @Override
    public String toString() {
        return "OrdersDTO [orderPrice=" + orderPrice + ", courseIdList=" + courseIdList + ", customerId=" + customerId
                + "]";
    }


    

    

    





}
