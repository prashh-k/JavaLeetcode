import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { apiUrl } from '../apiconfig';

@Injectable({
  providedIn: 'root'
})

export class CustomerService {
  constructor(private http:HttpClient) { }
  registerCustomer(customer:any):Observable<any>{
    return this.http.post<any>(apiUrl+"/customer",customer);
  }
  viewCustomerById(customerId:any):Observable<any>{
    return this.http.get<any>(apiUrl+"/customer/"+customerId);
  }
  viewCustomerByUserId(userId:any):Observable<any>{
    return this.http.get<any>(apiUrl+"/customer/user/"+userId);
  }
  viewAllCustomer():Observable<any>{
    return this.http.get(apiUrl+"/customer");
  }
}

