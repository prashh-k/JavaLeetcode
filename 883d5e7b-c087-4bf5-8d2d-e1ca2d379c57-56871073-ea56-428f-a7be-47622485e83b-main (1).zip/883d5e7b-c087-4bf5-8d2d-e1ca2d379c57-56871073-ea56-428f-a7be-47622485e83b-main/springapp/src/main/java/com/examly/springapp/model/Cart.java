package com.examly.springapp.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToOne;

@Entity
public class Cart {
    @Id
    @GeneratedValue
    Long cartId;
    @OneToOne
    Customer customer;
    @ManyToMany
    @JoinTable(name = "cart_course", joinColumns = @JoinColumn(name = "cartId"), inverseJoinColumns = @JoinColumn(name = "course_Id"))
    List<Course> courses;
    Double totalAmount;
    public Cart() {
    }
    public Cart(Long cartId, Customer customer, List<Course> courses, Double totalAmount) {
        this.cartId = cartId;
        this.customer = customer;
        this.courses = courses;
        this.totalAmount = totalAmount;

    }
    public Long getCartId() {
        return cartId;
    }
    public void setCartId(Long cartId) {
        this.cartId = cartId;
    }
    public Customer getCustomer() {
        return customer;
    }
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
    public List<Course> getCourses() {
        return courses;
    }
    public void setCourses(List<Course> courses) {
        this.courses = courses;
    }
    public Double getTotalAmount() {
        return totalAmount;
    }
    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }
    @Override
    public String toString() {
        return "Cart [cartId=" + cartId + ", customer=" + customer + ", courses=" + courses + ", totalAmount="
                + totalAmount + "]";
    }

}