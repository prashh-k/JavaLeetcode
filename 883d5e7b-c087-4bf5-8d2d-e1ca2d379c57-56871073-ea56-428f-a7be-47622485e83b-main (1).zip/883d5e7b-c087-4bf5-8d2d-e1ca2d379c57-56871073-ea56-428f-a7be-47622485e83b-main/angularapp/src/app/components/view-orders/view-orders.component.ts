
import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Course } from 'src/app/models/course.model';
import { Order } from 'src/app/models/order.model';
import { OrderService } from 'src/app/services/order.service';

@Component({
  selector: 'app-view-orders',
  templateUrl: './view-orders.component.html',
  styleUrls: ['./view-orders.component.css']
})
export class ViewOrdersComponent implements OnInit {
  addForm:FormGroup;
  order:Order;
  orders:any[]=[];
  orignalOrders:any[]=[];
  courses:Course[]=[];
  searchTerm: string ='';
  sortBy: string = '';
  sortOrder: string = 'asc';

  constructor(private orderService: OrderService) { }

  ngOnInit(): void {
    console.log("in view all orders in ngOnInIt");

    this.viewAllOrder();
  }

  addOrder(){
    if(this.addForm.valid){
      this.orderService.addOrder(this.addForm.value).subscribe((data)=>{
        this.order=data;
        this.viewAllOrder();
      })
    }
  }

  viewAllOrder(){
    console.log("in view all orders in component");
    this.orderService.viewAllOrders().subscribe((data)=>{
      console.log(data);
      this.orignalOrders = data;
      this.orders=data;
    })
  }
  viewOrderByUserId(customerId){
    this.orderService.viewOrderByUserId(customerId);
  }
  viewOrderByCustomerId(customerId){
    this.orderService.viewOrderByCustomerId(customerId);
  }
  deleteOrder(orderId){
    this.orderService.deleteOrder(orderId);
  }

  

  sort() {
    if (this.sortBy && this.sortOrder) {
      this.orders.sort((a, b) => {
        let comparison = 0;
        if (this.sortBy === 'price') {
          comparison = a.orderPrice - b.orderPrice;
        } else if (this.sortBy === 'quantity') {
          comparison = a.courses.length - b.courses.length;
        }
        return this.sortOrder === 'asc' ? comparison : -comparison;
      });
    }
  }

  search() {
    let term = this.searchTerm.trim().toLowerCase();
    if (term === '') {
      this.orders = this.orignalOrders;
    } else {
      this.orders = this.orignalOrders.filter((order) => {
        return order.courses.some((course) =>
          course.courseType.toLowerCase().includes(term) ||
          course.courseDetails.toLowerCase().includes(term)
        );
      });
    }
  }



}

