import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { imageUrl } from 'src/app/apiconfig';
import { Cart } from 'src/app/models/cart.model';
import { Course } from 'src/app/models/course.model';
import { AuthService } from 'src/app/services/auth.service';
import { CartService } from 'src/app/services/cart.service';
import { CustomerService } from 'src/app/services/customer.service';

@Component({
  selector: 'app-my-cart',
  templateUrl: './my-cart.component.html',
  styleUrls: ['./my-cart.component.css']
})
export class MyCartComponent implements OnInit {

  constructor(private cartService: CartService,
    private router: Router,
    private authService: AuthService,
    private customerService: CustomerService,
    private toastrService:ToastrService) { }
  cartId: number;
  cart: Cart = {};
  courses: Course[] = [];
  orderPrice: number;
  imgUrl = imageUrl;

  ngOnInit(): void {
    this.cartId = parseInt(this.authService.getCartId());
    if (parseInt(this.authService.getCartId()) != -1)
      this.getAllCourses();
  }

  
  getAllCourses() {
    this.cartService.getCartByCartId(this.cartId).subscribe((data) => {
      this.courses = data.courses;
    });
  }
  
  buy() {
    this.orderPrice = 0;
    let courseIdList = [];
    for (let course of this.courses) {
      this.orderPrice += course.coursePrice;
      courseIdList.push(course.courseId);
    }

    this.customerService.viewCustomerByUserId(this.authService.getAuthenticatedUserId()).subscribe(data => {
      let order = {
        orderPrice: this.orderPrice,
        courseIdList: courseIdList,
        customerId: data.customerId
      }
      this.router.navigate(['/place-order'], { queryParams: order });

    })

  }

  deleteCourse(courseId) {
    this.cartService.removeCoursesFromCart(this.cartId, courseId).subscribe((data) => {
      console.log("course deleted from cart");
      this.toastrService.success("course removed from cart");
      this.getAllCourses();
    });
  }
}
