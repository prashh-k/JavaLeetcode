package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.examly.springapp.model.Course;
import com.examly.springapp.service.CourseService;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/api/course")
public class CourseController {
    CourseService courseService;

    @Autowired
    public CourseController(CourseService courseService) {
        this.courseService = courseService;
    }

    @PostMapping
    public ResponseEntity<Course> addNewCourse(@RequestParam("uploadFile") MultipartFile uploadFile,
            @RequestParam("course") String course) {
                System.out.println("uploadfile:"+uploadFile);
                System.out.println("course:"+course);
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            Course courseObj = objectMapper.readValue(course, Course.class);
            System.out.println(courseObj);
            Course newCourse = courseService.addNewCourse(uploadFile, courseObj.getCourseType(),
                    courseObj.getCourseDetails(), courseObj.getCoursePrice());
            return ResponseEntity.status(201).body(newCourse);

        } catch (Exception e) {
            return ResponseEntity.status(500).build();
        }
    }

    // @PostMapping
    // public ResponseEntity<Course> addNewCourse(@RequestBody Course course){
    // Course newCourse=courseService.addNewCourse(course);
    // if(newCourse==null){
    // return ResponseEntity.status(500).build();
    // }
    // return ResponseEntity.status(201).body(newCourse);
    // }

    @GetMapping
    public ResponseEntity<List<Course>> getAllCourses() {
        List<Course> list = courseService.getAllCourses();
        return ResponseEntity.status(200).body(list);
    }

    @PutMapping("/{courseId}")
    public ResponseEntity<Integer> editExistingCourse(@PathVariable Long courseId, @RequestBody Course course) {
        int isUpdated = courseService.editExistingCourse(course.getCourseType(),course.getCourseDetails(),course.getCoursePrice(),courseId);
        if (isUpdated == 0) {
            return ResponseEntity.status(500).build();
        }
        return ResponseEntity.status(200).body(isUpdated);
    }

    // @PutMapping("/{courseId}")
    // public ResponseEntity<Course> editExistingCourse(@PathVariable long courseId, @RequestBody Course course) {
    //     Course newCourse = courseService.editExistingCourse(courseId, course);
    //     if (newCourse == null) {
    //         return ResponseEntity.status(500).build();
    //     }
    //     return ResponseEntity.status(200).body(newCourse);
    // }

    @GetMapping("/{courseId}")
    public ResponseEntity<Course> getCourseByCourseId(@PathVariable long courseId) {
        Course newCourse = courseService.getCourseByCourseId(courseId);
        if (newCourse == null) {
            return ResponseEntity.status(404).build();
        }
        return ResponseEntity.status(200).body(newCourse);
    }

    @DeleteMapping("/{courseId}")
    public ResponseEntity<Void> deleteCourseByCourseId(@PathVariable long courseId) {
        boolean course = courseService.deleteCourseByCourseId(courseId);
        if (course) {
            return ResponseEntity.status(200).build();
        }
        return ResponseEntity.status(500).build();
    }
}
