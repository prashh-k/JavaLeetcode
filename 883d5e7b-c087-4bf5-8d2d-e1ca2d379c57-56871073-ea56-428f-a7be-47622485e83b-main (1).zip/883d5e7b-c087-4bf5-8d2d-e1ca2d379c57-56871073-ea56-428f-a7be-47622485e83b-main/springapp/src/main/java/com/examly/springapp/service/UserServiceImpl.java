package com.examly.springapp.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.examly.springapp.DTO.LoginResponseDTO;
import com.examly.springapp.config.JwtService;
import com.examly.springapp.exception.PreexistingEmailException;
import com.examly.springapp.exception.PreexistingMobileNumberException;
import com.examly.springapp.exception.PreexistingUsernameException;
import com.examly.springapp.model.Cart;
import com.examly.springapp.model.LoginDTO;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.CartRepo;
import com.examly.springapp.repository.UserRepo;

@Service
public class UserServiceImpl implements UserService {

    UserRepo userRepo;
    CartRepo cartRepo;
    AuthenticationManager authManager;
    JwtService jwtService;
    PasswordEncoder passwordEncoder;

    @Autowired
    public UserServiceImpl(UserRepo userRepo, AuthenticationManager authManager, JwtService jwtService,
            PasswordEncoder passwordEncoder, CartRepo cartRepo) {
        this.authManager = authManager;
        this.userRepo = userRepo;
        this.jwtService = jwtService;
        this.passwordEncoder = passwordEncoder;
        this.cartRepo = cartRepo;

    }

    @Override
    public User getUserByUserId(Long userId) {
        Optional<User> optUser = userRepo.findById(userId);
        if (optUser.isPresent()) {
            return userRepo.save(optUser.get());
        }
        return null;
    }

    @Override
    public User getUserByUsername(String username) {
        return userRepo.findByUsername(username);
    }

    public User register(User user) {
 
        User u = userRepo.findByEmail(user.getEmail());

        if (u != null) {

            throw new PreexistingEmailException("User with email already exists", 409);

        }

        User un = userRepo.findByUsername(user.getUsername());

        if (un != null) {

            throw new PreexistingUsernameException("User with username already exists", 409);

        }

        User um = userRepo.findByMobileNumber(user.getMobileNumber());

        if (um != null) {

            throw new PreexistingMobileNumberException("User with mobile number already exists", 409);

        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));

        return userRepo.save(user);
 
    }
 
    @Override

    public LoginResponseDTO login(LoginDTO loginDTO) {

        User optUser = userRepo.findByUsername(loginDTO.getUsername());

        if (optUser == null) {

            throw new UsernameNotFoundException("Username does not exists");

        }

        Authentication authentication = authManager

                .authenticate(new UsernamePasswordAuthenticationToken(loginDTO.getUsername(), loginDTO.getPassword()));

        if (authentication.isAuthenticated()) {

            String token = jwtService.GenerateToken(loginDTO.getUsername());
 
            User returnUser = userRepo.findByUsername(loginDTO.getUsername());

            LoginResponseDTO loginResDTO = new LoginResponseDTO();

            loginResDTO.setUserId(returnUser.getUserId());

            loginResDTO.setRole(returnUser.getRole());

            Cart cart = cartRepo.findByCustomer_User_UserId(returnUser.getUserId());

            if (cart != null)

                loginResDTO.setCartId(cart.getCartId());

            else

                loginResDTO.setCartId(-1L);
 
            loginResDTO.setToken(token);

            // System.out.println("Token: " + token);

            return loginResDTO;
 
        }

        return null;

    }
 

}
