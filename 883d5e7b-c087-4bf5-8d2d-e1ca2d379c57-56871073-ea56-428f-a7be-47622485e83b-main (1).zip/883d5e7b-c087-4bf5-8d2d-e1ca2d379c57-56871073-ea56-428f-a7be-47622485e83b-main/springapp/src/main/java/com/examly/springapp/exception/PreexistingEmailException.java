package com.examly.springapp.exception;

public class PreexistingEmailException extends RuntimeException{
    int status;

    public PreexistingEmailException(String message , int status)
    {
        super(message);
        this.status = status;
    }

    public int getStatus()
    {
        return status;
    }
}
