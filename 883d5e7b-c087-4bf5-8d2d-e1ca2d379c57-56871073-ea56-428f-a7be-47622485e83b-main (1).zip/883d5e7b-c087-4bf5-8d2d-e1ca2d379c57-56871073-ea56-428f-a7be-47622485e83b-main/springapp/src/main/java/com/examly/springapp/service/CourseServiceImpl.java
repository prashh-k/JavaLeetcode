package com.examly.springapp.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.examly.springapp.model.Course;
import com.examly.springapp.repository.CourseRepo;

@Service
public class CourseServiceImpl implements CourseService {
    CourseRepo courseRepo;

    private String uploadDir = "src/main/resources/static/images/";

    @Autowired
    public CourseServiceImpl(CourseRepo courseRepo) {
        this.courseRepo = courseRepo;
    }
    // @Override
    // public Course addNewCourse(Course course) {
    // return courseRepo.save(course);
    // }

    @Override
    public Course addNewCourse(MultipartFile uploadFile, String courseType, String courseDetails, Double coursePrice)
            throws IOException {
        File directory = new File(uploadDir);
        if (!directory.exists())
            directory.mkdir();

        long time = System.currentTimeMillis();
        String fileName = uploadFile.getOriginalFilename();
        String newFileName = fileName.substring(0, fileName.indexOf(".")) + time
                + fileName.substring(fileName.indexOf("."));

        Path filePath = Paths.get(uploadDir, newFileName);

        Files.write(filePath, uploadFile.getBytes());

        Course course = new Course();
        course.setCourseDetails(courseDetails);
        course.setCoursePrice(coursePrice);
        course.setCourseType(courseType);

        course.setCourseImageUrl(newFileName.toString());

        return courseRepo.save(course);
    }

    @Override
    public boolean deleteCourseByCourseId(Long id) {
        Optional<Course> optCourse = courseRepo.findById(id);
        if (optCourse.isPresent()) {
            courseRepo.delete(optCourse.get());
            return true;
        }
        return false;
    }

    @Override
    public int editExistingCourse(String courseType, String courseDetails, Double coursePrice, Long courseId) {
        Optional<Course> optCourse = courseRepo.findById(courseId);
        if (optCourse.isPresent()) {
            return courseRepo.updateCourse(courseType, courseDetails, coursePrice, courseId);
        }
        return 0;
    }

    // @Override
    // public Course editExistingCourse(long id, Course course) {
    // Optional<Course> optCourse = courseRepo.findById(id);
    // if (optCourse.isPresent()) {
    // Course courseData = optCourse.get();
    // courseData.setCourseType(course.getCourseType());
    // courseData.setCourseImageUrl(course.getCourseImageUrl());
    // courseData.setCourseDetails(course.getCourseDetails());
    // courseData.setCoursePrice(course.getCoursePrice());
    // return courseRepo.save(courseData);

    // }
    // return null;
    // }

    @Override
    public List<Course> getAllCourses() {
        return courseRepo.findAll();
    }

    @Override
    public Course getCourseByCourseId(Long id) {
        Optional<Course> optCourse = courseRepo.findById(id);
        if (optCourse.isPresent()) {
            return optCourse.get();
        }
        return null;
    }
    
}
