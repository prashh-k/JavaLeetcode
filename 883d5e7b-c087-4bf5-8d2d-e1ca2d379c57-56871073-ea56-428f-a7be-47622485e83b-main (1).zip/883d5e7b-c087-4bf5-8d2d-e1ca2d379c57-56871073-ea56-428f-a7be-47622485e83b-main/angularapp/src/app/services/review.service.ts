import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { apiUrl } from '../apiconfig';

@Injectable({
  providedIn: 'root'
})

export class ReviewService {

  constructor(private httpClient : HttpClient) { }

  addReview(review : any) : Observable<any>
  {
    return this.httpClient.post(`${apiUrl}/review`,review);
  }

  getAllReviews() : Observable<any>
  {
    return this.httpClient.get(`${apiUrl}/review`);
  }
}

