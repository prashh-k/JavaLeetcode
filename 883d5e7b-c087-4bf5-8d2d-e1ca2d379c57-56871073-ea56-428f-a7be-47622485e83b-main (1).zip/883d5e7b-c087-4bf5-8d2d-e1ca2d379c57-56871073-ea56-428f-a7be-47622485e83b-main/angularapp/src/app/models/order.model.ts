import { Customer } from "./customer.model";

export interface Order{
    orderId?:number;
    orderPrice?:number;
    courseIds?:number[];
    customerId?:number;
}