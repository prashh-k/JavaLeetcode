import { CurrencyPipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/services/auth.service';
import { CartService } from 'src/app/services/cart.service';
import { OrderService } from 'src/app/services/order.service';

@Component({
  selector: 'app-place-order',
  templateUrl: './place-order.component.html',
  styleUrls: ['./place-order.component.css']
})
export class PlaceOrderComponent implements OnInit {

  makePaymentForm: FormGroup;
  order: any;
  cartId: number;

  constructor(private formBuilder: FormBuilder,
    private actRouter: ActivatedRoute,
    private router: Router,
    private authService: AuthService,
    private orderService: OrderService,
    private cartService: CartService,
    private toastrService:ToastrService,
    private currencyPipe: CurrencyPipe) {
    this.makePaymentForm = this.formBuilder.group({
      name: [""],
      mobileNumber: [""],
      email: [""],
      price: [""]
    })
  }
  ngOnInit(): void {
    this.actRouter.queryParams.subscribe(params => {
      this.order = {
        ...params,
        courseIdList : Array.isArray(params.courseIdList)?params.courseIdList : [params.courseIdList]
      };

      this.authService.getUserByUserId(this.authService.getAuthenticatedUserId()).subscribe(user => {
        const formattedPrice = this.currencyPipe.transform(this.order.orderPrice, 'INR', 'symbol', '1.2-2');
        this.makePaymentForm.patchValue({
          name: user.username,
          mobileNumber: user.mobileNumber,
          email: user.email,
          price: formattedPrice
        });
      })

      // console.log(this.user);
      this.cartId = parseInt(this.authService.getCartId());
    });
  }
  makePayment() {
    console.log("in payment fun");
    console.log("order:",this.order)
    this.orderService.addOrder(this.order).subscribe(data => {
      
      this.toastrService.success("payment successfull.");
      // alert("payment successfull.");
      for (let courseId of this.order.courseIdList) {
        this.cartService.removeCoursesFromCart(this.cartId, courseId).subscribe();
      }
      this.router.navigate(['/my-orders'])
    })
  }

}