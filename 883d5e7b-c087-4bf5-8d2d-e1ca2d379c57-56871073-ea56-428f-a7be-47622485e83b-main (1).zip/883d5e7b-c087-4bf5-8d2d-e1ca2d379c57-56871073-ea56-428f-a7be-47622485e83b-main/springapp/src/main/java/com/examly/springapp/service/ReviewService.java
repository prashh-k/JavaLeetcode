package com.examly.springapp.service;

import java.util.List;

import com.examly.springapp.DTO.ReviewDTO;
import com.examly.springapp.model.Review;

public interface ReviewService {
    public Review createReview(ReviewDTO reviewDTO);

    public List<Review> getAllReviews();

    public Review getReviewById(long reviewId);

    // public boolean deleteReviewById(long reviewId);


}
