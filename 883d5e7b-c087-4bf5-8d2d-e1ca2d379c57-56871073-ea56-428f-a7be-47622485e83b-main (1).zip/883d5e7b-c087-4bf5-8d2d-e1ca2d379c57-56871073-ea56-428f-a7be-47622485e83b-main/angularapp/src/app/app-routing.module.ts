import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { AddCourseComponent } from './components/add-course/add-course.component';
import { AddReviewComponent } from './components/add-review/add-review.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { CustomerViewCoursesComponent } from './components/customer-view-courses/customer-view-courses.component';
import { CustomerdashboardComponent } from './components/customerdashboard/customerdashboard.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { EditCourseComponent } from './components/edit-course/edit-course.component';
import { ErrorComponent } from './components/error/error.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { MyCartComponent } from './components/my-cart/my-cart.component';
import { MyOrdersComponent } from './components/my-orders/my-orders.component';
import { PlaceOrderComponent } from './components/place-order/place-order.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { ViewCoursesComponent } from './components/view-courses/view-courses.component';
import { ViewOrdersComponent } from './components/view-orders/view-orders.component';
import { ViewReviewComponent } from './components/view-review/view-review.component';
import { AuthGuardService } from './services/auth-guard.service';
import { CustomerDashboardCoursesComponent } from './components/customer-dashboard-courses/customer-dashboard-courses.component';
import { CustomerDashboardPracticeComponent } from './components/customer-dashboard-practice/customer-dashboard-practice.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },
  { path: 'add-course', component: AddCourseComponent, canActivate: [AuthGuardService], data: { expectedRole: 'Admin' } },
  { path: 'edit-course/:courseId', component: EditCourseComponent, canActivate: [AuthGuardService], data: { expectedRole: 'Admin' } },
  { path: 'add-review', component: AddReviewComponent, canActivate: [AuthGuardService], data: { expectedRole: 'User' } },
  { path: 'customer-view-courses', component: CustomerViewCoursesComponent },
  { path: 'customerdashboard', component: CustomerdashboardComponent, canActivate: [AuthGuardService], data: { expectedRole: 'User' } },
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuardService], data: { expectedRole: 'Admin' } },
  { path: 'error', component: ErrorComponent },
  { path: 'login', component: LoginComponent },
  { path: 'my-cart', component: MyCartComponent, canActivate: [AuthGuardService], data: { expectedRole: 'User' } },
  { path: 'my-orders', component: MyOrdersComponent, canActivate: [AuthGuardService], data: { expectedRole: 'User' } },
  // {path:'navbar',component:NavbarComponent},
  { path: 'place-order', component: PlaceOrderComponent, canActivate: [AuthGuardService], data: { expectedRole: 'User' } },
  { path: 'registration', component: RegistrationComponent },
  { path: 'view-courses', component: ViewCoursesComponent, canActivate: [AuthGuardService], data: { expectedRole: 'Admin' } },
  { path: 'view-orders', component: ViewOrdersComponent, canActivate: [AuthGuardService], data: { expectedRole: 'Admin' } },
  { path: 'customer-dashboard-courses', component: CustomerDashboardCoursesComponent, canActivate: [AuthGuardService], data: { expectedRole: 'User' } },
  { path: 'customer-dashboard-practice', component: CustomerDashboardPracticeComponent, canActivate: [AuthGuardService], data: { expectedRole: 'User' } },
  { path: 'view-review', component: ViewReviewComponent },
  { path: 'about-us', component: AboutUsComponent },
  { path: 'contact-us', component: ContactUsComponent },
  { path: '**', redirectTo: "error" }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
