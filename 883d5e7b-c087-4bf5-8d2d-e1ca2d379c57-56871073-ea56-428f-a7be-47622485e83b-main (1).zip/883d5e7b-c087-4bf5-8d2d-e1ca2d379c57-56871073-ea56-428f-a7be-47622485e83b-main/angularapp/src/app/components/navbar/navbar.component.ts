import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/services/auth.service';
 
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
 
  notLogin: boolean = true;
  admin: boolean;
  student: boolean;
 
  role: string = '';
  currentRoute: string;
 
  userName: string = '';
  userNameInProfile: string = '';
 
  showProfile = false;
  hideTimeout: any;
  hideProfileTimeout: any;
 
  constructor(private authService: AuthService, private router: Router,private toastrService:ToastrService) { }
 
  ngOnInit(): void {
    this.authService.authenticatedUser$.subscribe(user => {
      if (user) {
        this.userName = user.toUpperCase();
        this.userNameInProfile = this.userName[0] + this.userName[1];
      } else {
        this.userName = '';
        this.userNameInProfile = '';
      }
    });
  }
 
  isLoggedIn() {
    return this.authService.isUserLoggedIn();
  }
 
  isAdmin() {
    return this.authService.isAdmin();
  }
 
  isUser() {
    return this.authService.isUser();
  }
 
  logout() {
    this.toastrService.warning('click to confirm', 'Are you sure you want to logout?', {
      closeButton: true,
      tapToDismiss: false,
      timeOut: 0,
      extendedTimeOut: 0,
      enableHtml: true,
      toastClass: 'ngx-toastr confirm-logout-toast',
      onActivateTick: true
    }).onTap.subscribe(() => {
      
        this.authService.logout();
        this.router.navigate(['/login']);
  
        this.toastrService.clear();

    });

  }
 
  viewCourses() {
    this.router.navigate(['/view-courses']);
  }
 
  addCourse() {
    this.router.navigate(['/add-course']);
  }
 
  viewEnrollments() {
    this.router.navigate(['/view-orders']);
  }
 
  viewReviews() {
    this.router.navigate(['/view-review']);
  }
 
  avaliableCourses() {
    this.router.navigate(['/customer-view-courses']);
  }
 
  customerDashboard() {
    this.router.navigate(['/customerdashboard']);
  }
 
  myCart() {
    this.router.navigate(['/my-cart']);
  }
 
  myEnrollments() {
    this.router.navigate(['/my-orders']);
  }
 
  addReviews() {
    this.router.navigate(['/add-review']);
  }
 
  showProfileOptions() {
    clearTimeout(this.hideProfileTimeout);
    this.showProfile = true;
  }
 
  delayedHideProfileOptions() {
    this.hideProfileTimeout = setTimeout(() => {
      this.showProfile = false;
    }, 5000);
  }
 
  toggleProfileOptions() {
    this.showProfile = !this.showProfile;
  }
}
