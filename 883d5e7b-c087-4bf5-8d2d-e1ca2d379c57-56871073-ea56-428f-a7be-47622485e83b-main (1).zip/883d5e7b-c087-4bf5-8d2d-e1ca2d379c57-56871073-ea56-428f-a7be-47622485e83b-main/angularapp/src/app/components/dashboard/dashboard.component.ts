import { Component, OnInit } from '@angular/core';
import { ChartDataSets, ChartOptions, ChartType } from 'chart.js';
import { Label } from 'ng2-charts';
import { Course } from 'src/app/models/course.model';
import { Customer } from 'src/app/models/customer.model';
import { Review } from 'src/app/models/review.model';
import { CourseService } from 'src/app/services/course.service';
import { CustomerService } from 'src/app/services/customer.service';
import { OrderService } from 'src/app/services/order.service';
import { ReviewService } from 'src/app/services/review.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  reviews: Review[];
  firstreview: Review;
  customers: Customer[];
  orders: any[];
  courses: Course[];
  countOfCustomer: number;
  totalIncome: number;
  one: number = 0;
  two: number = 0;
  three: number = 0;
  four: number = 0;
  five: number = 0;
  coursePopularity: { [key: number]: number } = {}; // Key: courseId, Value: count

  // Bar chart properties
  barChartOptions: ChartOptions = {
    responsive: true,
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
          callback: (value) => {
            const uniqueValues = Object.values(this.coursePopularity);
            return uniqueValues.includes(Number(value)) ? value : null;
          }
        },
        gridLines: {
          display: true
        }
      }],
      xAxes: [{
        gridLines: {
          display: false
        }
      }]
    }
  };
  barChartLabels: Label[] = [];
  barChartType: ChartType = 'bar';
  barChartLegend = true;
  barChartPlugins = [];
  barChartData: ChartDataSets[] = [
    { data: [], label: 'Number of Customers' }
  ];

  constructor(
    private reviewService: ReviewService,
    private customerService: CustomerService,
    private orderService: OrderService,
    private courseService: CourseService
  ) { }

  ngOnInit(): void {
    this.getAllCourses();
    this.getAllReviews();
    this.getCustomerCount();
    this.getTotalIncome();
    this.getMostPopularCourses();
  }

  getAllReviews() {
    this.reviewService.getAllReviews().subscribe((data) => {
      this.reviews = data;
      if (this.reviews && this.reviews.length > 0) {
        this.firstreview = this.reviews[0];
      }
      for (let i = 0; i < this.reviews.length; i++) {
        if (this.reviews[i].rating === 1) { this.one++; }
        if (this.reviews[i].rating === 2) { this.two++; }
        if (this.reviews[i].rating === 3) { this.three++; }
        if (this.reviews[i].rating === 4) { this.four++; }
        if (this.reviews[i].rating === 5) { this.five++; }
      }
    });
  }

  getAllCourses() {
    this.courseService.viewAllCourses().subscribe((data) => {
      this.courses = data;
      console.log("courses", this.courses);
    });
  }

  getCustomerCount() {
    this.customerService.viewAllCustomer().subscribe((data) => {
      this.customers = data;
      this.countOfCustomer = this.customers.length;
    });
  }

  getTotalIncome() {
    this.orderService.viewAllOrders().subscribe((data) => {
      this.orders = data;
      this.totalIncome = 0;
      for (let i = 0; i < this.orders.length; i++) {
        this.totalIncome += this.orders[i].orderPrice;
      }
    });
  }

  getMostPopularCourses() {
    this.orderService.viewAllOrders().subscribe((data) => {
      this.orders = data;
      this.coursePopularity = {};
      console.log("in view all orders");
      for (let order of this.orders) {
        console.log("in orders loop", this.orders);
        for (let course of order.courses) {
          console.log("in course loop", course);
          if (this.coursePopularity[course.courseId]) {
            console.log("in if loop");
            this.coursePopularity[course.courseId]++;
          } else {
            console.log("in else loop");
            this.coursePopularity[course.courseId] = 1;
          }
        }
      }
      console.log('coursePopularity:', this.coursePopularity);
      this.updateChart();
    });
  }

  updateChart() {
    console.log('coursePopularity:', this.coursePopularity); // Debugging line
    this.barChartLabels = this.courses.map(course => course.courseDetails);
    this.barChartData[0].data = this.courses.map(course => this.coursePopularity[course.courseId] || 0);
    console.log('barChartLabels:', this.barChartLabels); // Debugging line
    console.log('barChartData:', this.barChartData); // Debugging line
  }

  getSortedCourseIds(): number[] {
    return Object.keys(this.coursePopularity)
      .map(key => parseInt(key, 10))
      .sort((a, b) => this.coursePopularity[b] - this.coursePopularity[a]);
  }

  getStarRating(rating: number): string {
    return '⭐'.repeat(rating);
  }
}