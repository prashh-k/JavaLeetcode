import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { imageUrl } from 'src/app/apiconfig';
import { AuthService } from 'src/app/services/auth.service';
import { OrderService } from 'src/app/services/order.service';

@Component({
  selector: 'app-my-orders',
  templateUrl: './my-orders.component.html',
  styleUrls: ['./my-orders.component.css']
})
export class MyOrdersComponent implements OnInit {
  myOrders: any = [];
  orignalOrders:any[]=[];
  totalOrderCost: number = 0;
  imgUrl = imageUrl;
  searchTerm: string = '';
  sortBy: string = '';
  sortOrder: string = 'asc';

  constructor(
    private orderService: OrderService,
    private router: Router,
    private authService: AuthService
  ) { }

  ngOnInit(): void {
    this.loadOrders();
  }

  loadOrders(){
    if(this.authService.getCartId() && parseInt(this.authService.getCartId()) !== -1){

      this.orderService.viewOrderByUserId(this.authService.getAuthenticatedUserId()).subscribe((data) => {
        this.orignalOrders=data;
        this.myOrders = data;
        
        this.calculateTotalOrderCost();
      });
    }

  }

  calculateTotalOrderCost(): void {
    this.totalOrderCost = this.myOrders.reduce((total, order) => total + order.orderPrice, 0);
  }

  addReview() {
    this.router.navigate(['/add-review']);
  }

  search(): void {
    let term = this.searchTerm.trim().toLowerCase();
    if (term === '') {
      this.myOrders = this.orignalOrders;
    } else {
      this.myOrders = this.orignalOrders.filter((order) => {
        return order.courses.some((course) =>
          course.courseType.toLowerCase().includes(term) ||
          course.courseDetails.toLowerCase().includes(term)
        );
      });
    }
  }


  sort(): void {
    if (this.sortBy && this.sortOrder) {
      this.myOrders.sort((a, b) => {
        let comparison = 0;
        if (this.sortBy === 'price') {
          comparison = a.orderPrice - b.orderPrice;
        } else if (this.sortBy === 'quantity') {
          comparison = a.courses.length - b.courses.length;
        }
        return this.sortOrder === 'asc' ? comparison : -comparison;
      });
    }
  }

}

