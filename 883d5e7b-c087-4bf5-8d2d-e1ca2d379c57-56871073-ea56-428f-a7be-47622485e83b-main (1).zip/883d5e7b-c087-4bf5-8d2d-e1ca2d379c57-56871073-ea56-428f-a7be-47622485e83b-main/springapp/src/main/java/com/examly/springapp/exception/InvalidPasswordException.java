package com.examly.springapp.exception;

public class InvalidPasswordException extends RuntimeException{
    int status;

    public InvalidPasswordException(String message , int status) {
        super(message);
        this.status = status;
    }

    public int getStatus()
    {
        return status;
    }

    
    
}
