package com.examly.springapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.DTO.CartDTO;
import com.examly.springapp.model.Cart;
import com.examly.springapp.model.Course;
import com.examly.springapp.repository.CartRepo;
import com.examly.springapp.repository.CourseRepo;
import com.examly.springapp.repository.CustomerRepo;

@Service
public class CartServiceImpl implements CartService {

    CartRepo cartRepo;
    CourseRepo courseRepo;
    CustomerRepo customerRepo;

    @Autowired
    public CartServiceImpl(CartRepo cartRepo, CourseRepo courseRepo, CustomerRepo customerRepo) {
        this.cartRepo = cartRepo;
        this.courseRepo = courseRepo;
        this.customerRepo = customerRepo;
    }

    @Override
    public Cart newCart(CartDTO cartDTO) {
        Cart cart = new Cart();

        List<Course> courses = new ArrayList<>();

        for (Long courseId : cartDTO.getCourseIdList()) {
            courses.add(courseRepo.findById(courseId).get());
        }

        cart.setTotalAmount(cartDTO.getTotalAmount());
        cart.setCustomer(customerRepo.findById(cartDTO.getCustomerId()).get());
        cart.setCourses(courses);

        return cartRepo.save(cart);
    }

    public Long getCartIdByUserId(Long userId){
        return cartRepo.findById(userId).get().getCartId();
    }
    @Override
    public List<Cart> getAllCarts() {
        return cartRepo.findAll();
    }

    @Override
    public Cart getCartByCartId(Long cartId) {
        Optional<Cart> optCart = cartRepo.findById(cartId);
        if (optCart.isPresent())
            return optCart.get();
        return null;
    }

    @Override
    public Cart editCart(Long cartId, CartDTO cartDTO) {
        Optional<Cart> optCart = cartRepo.findById(cartId);
        if (optCart.isPresent()) {

            List<Course> courses = new ArrayList<>();

            for (Long courseId : cartDTO.getCourseIdList()) {
                courses.add(courseRepo.findById(courseId).get());
            }

            Cart existingCart = optCart.get();
            existingCart.setCourses(courses);
            existingCart.setCustomer(customerRepo.findById(cartDTO.getCustomerId()).get());
            existingCart.setTotalAmount(cartDTO.getTotalAmount());
            return cartRepo.save(existingCart);
        }
        return null;

    }

    @Override
    public Cart getCartByCustomerId(Long customerId) {
        Cart newCart = cartRepo.findByCustomer_CustomerId(customerId);
        if (newCart != null)
            return newCart;
        return null;
    }

    @Override
    public Cart getCartByUserId(Long userId) {
        Cart newCart = cartRepo.findByCustomer_User_UserId(userId);
        if (newCart != null)
            return newCart;
        return null;
    }

    @Override
    public Cart addCourseToCart(Long cartId, Long courseId) {
        Optional<Cart> optCart = cartRepo.findById(cartId);
        Optional<Course> optCourse = courseRepo.findById(courseId);
        if (optCart.isPresent()  && optCourse.isPresent()) {
 
            Cart existingCart = optCart.get();
            existingCart.getCourses().add(optCourse.get());
            existingCart.setTotalAmount(existingCart.getTotalAmount() + optCourse.get().getCoursePrice() ); 
            return cartRepo.save(existingCart);
        }
        return null;
    }

    @Override
    public Cart deleteCourseInCartByCourseId(Long cartId, Long courseId) {
        Optional<Cart> optCart = cartRepo.findById(cartId);
        Optional<Course> optCourse = courseRepo.findById(courseId);
        if (optCart.isPresent() && optCourse.isPresent()) {

            Cart existingCart = optCart.get();
            Course existingCourse = optCourse.get();
            List<Course> coursesInCart = existingCart.getCourses();
            coursesInCart.remove(existingCourse);

            existingCart.setCourses(coursesInCart);
            return cartRepo.save(existingCart);
        }

        return null;
    }

}