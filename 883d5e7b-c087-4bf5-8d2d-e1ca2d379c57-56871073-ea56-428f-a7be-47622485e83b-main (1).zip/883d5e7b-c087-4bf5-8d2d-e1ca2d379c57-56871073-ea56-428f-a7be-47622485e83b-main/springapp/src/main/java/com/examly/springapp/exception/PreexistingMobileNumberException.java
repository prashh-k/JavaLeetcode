package com.examly.springapp.exception;

public class PreexistingMobileNumberException extends RuntimeException{
    
    int status;

    public PreexistingMobileNumberException(String message , int status)
    {
        super(message);
        this.status = status;
    }

    public int getStatus()
    {
        return status;
    }
}
