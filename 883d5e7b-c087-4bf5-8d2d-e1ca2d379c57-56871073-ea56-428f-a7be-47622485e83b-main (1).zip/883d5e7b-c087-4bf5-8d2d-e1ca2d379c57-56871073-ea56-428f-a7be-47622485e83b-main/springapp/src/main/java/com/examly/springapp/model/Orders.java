package com.examly.springapp.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class Orders {
    @Id
    @GeneratedValue
    Long orderId;
    double orderPrice;
    
    @ManyToMany
    @JoinTable(
        name = "order_courses",
        joinColumns = @JoinColumn(name = "order_id"),
        inverseJoinColumns = @JoinColumn(name = "course_id")
    )
    
    List<Course> courses;
    @OneToOne
    Customer customer;
    public Orders() {
    }
    
    public Orders(Long orderId, double orderPrice, List<Course> courses, Customer customer) {
        this.orderId = orderId;
        this.orderPrice = orderPrice;
        this.courses = courses;
        this.customer = customer;
    }

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public double getOrderPrice() {
        return orderPrice;
    }
    public void setOrderPrice(double orderPrice) {
        this.orderPrice = orderPrice;
    }
    public List<Course> getCourses() {
        return courses;
    }
    public void setCourses(List<Course> courses) {
        this.courses = courses;
    }
    public Customer getCustomer() {
        return customer;
    }
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
    @Override
    public String toString() {
        return "Orders [orderId=" + orderId + ", orderPrice=" + orderPrice + ", courses=" + courses + ", customer="
                + customer + "]";
    }
     
}