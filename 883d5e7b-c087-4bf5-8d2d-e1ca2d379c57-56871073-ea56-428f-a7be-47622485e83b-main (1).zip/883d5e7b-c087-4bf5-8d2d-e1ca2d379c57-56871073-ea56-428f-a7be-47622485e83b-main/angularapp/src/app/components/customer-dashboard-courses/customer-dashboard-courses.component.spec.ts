import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerDashboardCoursesComponent } from './customer-dashboard-courses.component';

describe('CustomerDashboardCoursesComponent', () => {
  let component: CustomerDashboardCoursesComponent;
  let fixture: ComponentFixture<CustomerDashboardCoursesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerDashboardCoursesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerDashboardCoursesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
