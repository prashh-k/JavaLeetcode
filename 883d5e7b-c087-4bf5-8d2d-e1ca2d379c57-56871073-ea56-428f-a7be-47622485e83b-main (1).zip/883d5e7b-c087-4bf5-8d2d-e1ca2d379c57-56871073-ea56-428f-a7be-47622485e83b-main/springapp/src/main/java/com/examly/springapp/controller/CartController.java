
package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.DTO.CartDTO;
import com.examly.springapp.model.Cart;
import com.examly.springapp.service.CartServiceImpl;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    CartServiceImpl cartService;

    @Autowired
    public CartController(CartServiceImpl cartService) {
        this.cartService = cartService;
    }

    @PostMapping
    ResponseEntity<Cart> newCart(@RequestBody CartDTO cartDTO) {
        Cart newCart = cartService.newCart(cartDTO);
        if (newCart != null)
            return ResponseEntity.status(201).body(newCart);
        return ResponseEntity.status(500).build();
    }

    @GetMapping("/getCartId/{userId}")
    Long getCartIdByUserId(@PathVariable Long userId) {
        return cartService.getCartIdByUserId(userId);
    }

    @GetMapping
    ResponseEntity<List<Cart>> getAllCarts() {
        List<Cart> newCart = cartService.getAllCarts();
        if (!newCart.isEmpty())
            return ResponseEntity.status(200).body(newCart);
        return ResponseEntity.status(404).build();
    }

    @GetMapping("/{cartId}")
    ResponseEntity<Cart> getCartByCartId(@PathVariable Long cartId) {
        Cart newCart = cartService.getCartByCartId(cartId);
        if (newCart != null)
            return ResponseEntity.status(200).body(newCart);
        return ResponseEntity.status(404).build();
    }

    @GetMapping("/user/{userId}")
    ResponseEntity<Cart> getCartByUserId(@PathVariable Long userId) {
        Cart newCart = cartService.getCartByUserId(userId);
        if (newCart != null)
            return ResponseEntity.status(200).body(newCart);
        return ResponseEntity.status(404).build();
    }

    @GetMapping("/customer/{customerId}")
    ResponseEntity<Cart> getCartByCustomerId(@PathVariable Long customerId) {
        Cart newCart = cartService.getCartByCustomerId(customerId);
        if (newCart != null)
            return ResponseEntity.status(200).body(newCart);
        return ResponseEntity.status(404).build();
    }

    @PutMapping("/{cartId}/course/{courseId}")
    ResponseEntity<Cart> addCourseToCart(@PathVariable Long cartId, @PathVariable Long courseId) {
        Cart newCart = cartService.addCourseToCart(cartId, courseId);
        if (newCart != null)
            return ResponseEntity.status(200).body(newCart);
        return ResponseEntity.status(500).build();
    }

    @DeleteMapping("/{cartId}/course/{courseId}")
    ResponseEntity<Cart> deleteCourseInCartByCourseId(@PathVariable Long cartId, @PathVariable Long courseId) {
        Cart newCart = cartService.deleteCourseInCartByCourseId(cartId, courseId);
        if (newCart != null)
            return ResponseEntity.status(200).body(newCart);
        return ResponseEntity.status(500).build();
    }

    @PutMapping("/{cartId}")
    ResponseEntity<Cart> editCart(@PathVariable Long cartId, @RequestBody CartDTO cartDTO) {
        Cart newCart = cartService.editCart(cartId, cartDTO);
        if (newCart != null)
            return ResponseEntity.status(200).body(newCart);
        return ResponseEntity.status(500).build();
    }
}