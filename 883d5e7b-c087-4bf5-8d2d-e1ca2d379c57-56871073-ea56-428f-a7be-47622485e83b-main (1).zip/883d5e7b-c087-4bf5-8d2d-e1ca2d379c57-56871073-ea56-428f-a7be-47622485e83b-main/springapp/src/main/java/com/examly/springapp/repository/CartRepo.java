
package com.examly.springapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.examly.springapp.model.Cart;

@Repository
public interface CartRepo extends JpaRepository<Cart,Long>{
    Cart findByCustomer_User_UserId(Long userId);
    Cart findByCustomer_CustomerId(Long customerId);
}
