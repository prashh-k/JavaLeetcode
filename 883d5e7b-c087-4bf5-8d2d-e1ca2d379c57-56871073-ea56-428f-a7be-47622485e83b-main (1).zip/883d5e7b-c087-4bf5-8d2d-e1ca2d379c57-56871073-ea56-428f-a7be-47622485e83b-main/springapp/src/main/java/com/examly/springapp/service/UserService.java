package com.examly.springapp.service;

import com.examly.springapp.DTO.LoginResponseDTO;
import com.examly.springapp.model.LoginDTO;
import com.examly.springapp.model.User;

public interface UserService {
    
    User register(User user) ;
    LoginResponseDTO login(LoginDTO loginDTO) ;
    User getUserByUsername(String username);
    User getUserByUserId (Long userId);

}
