package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.DTO.CustomerDTO;
import com.examly.springapp.model.Customer;
import com.examly.springapp.repository.CustomerRepo;
import com.examly.springapp.repository.UserRepo;

@Service
public class CustomerServiceImpl implements CustomerService {

    CustomerRepo customerRepo;
    UserRepo userRepo;

    @Autowired
    public CustomerServiceImpl(CustomerRepo customerRepo, UserRepo userRepo) {
        this.customerRepo = customerRepo;
        this.userRepo = userRepo;
    }

    @Override
    public Customer addNewCustomer(CustomerDTO customerDTO) {
        Customer customer = new Customer();
        customer.setCustomerName(customerDTO.getCustomerName());
        customer.setInformation(customerDTO.getInformation());
        customer.setUser(userRepo.findById(customerDTO.getUserId()).get());
        return customerRepo.save(customer);
    }

    @Override
    public Customer getCustomerByCustomerId(Long customerId) {
        Optional<Customer> optCustomer = customerRepo.findById(customerId);
        if(optCustomer.isPresent()){
            return optCustomer.get();
        }
        return null;
    }

    @Override
    public Customer getCustomerByUserId(Long userId) {
        Customer customer = customerRepo.findByUser_UserId(userId);
        if(customer!=null){
            return customer;
        }
        return null;
    }

    @Override
    public List<Customer> getAllCustomers() {
        List<Customer> customerList = customerRepo.findAll();
        return customerList;
    }
    
    
}
