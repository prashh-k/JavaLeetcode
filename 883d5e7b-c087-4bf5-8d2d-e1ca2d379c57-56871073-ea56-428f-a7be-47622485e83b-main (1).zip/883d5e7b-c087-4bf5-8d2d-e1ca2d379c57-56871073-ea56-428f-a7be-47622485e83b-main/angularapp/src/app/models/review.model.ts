export interface Review 
{
    reviewId ?: number ;
    subject ?: String;
    body ?: String;
    rating ?: number;
    dateCreated ?: Date;
    customerId ?: number; 
    
}