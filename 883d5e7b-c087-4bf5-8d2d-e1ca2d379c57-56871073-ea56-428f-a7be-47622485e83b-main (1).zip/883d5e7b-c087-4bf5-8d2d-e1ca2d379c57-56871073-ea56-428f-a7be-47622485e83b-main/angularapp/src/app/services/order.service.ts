import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { apiUrl } from '../apiconfig';

@Injectable({
  providedIn: 'root'
})

export class OrderService {
  constructor(private http:HttpClient) { }
  addOrder(orderData:any):Observable<any>{
    return this.http.post<any>(apiUrl+"/order",orderData);
  }
  cancelOrder(orderId:any):Observable<any>{
    return this.http.delete<any>(apiUrl+"/order/"+orderId);
  }
  viewAllOrders():Observable<any>{
    return this.http.get(`${apiUrl}/order`);
  }
  viewOrderByCustomerId(customerId):Observable<any>{
    return this.http.get<any>(apiUrl+"/order/customer/"+customerId);
  }
  viewOrderByUserId(userId):Observable<any>{
    return this.http.get<any>(apiUrl+"/order/user/"+userId);
  }
  viewOrderById(orderId):Observable<any>{
    return this.http.get<any>(apiUrl+"/order/"+orderId);
  }
  deleteOrder(orderId:any):Observable<any>{
    return this.http.delete<any>(apiUrl+"/order/"+orderId);
  }
}