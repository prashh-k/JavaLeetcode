package com.examly.springapp.DTO;

import java.util.List;

public class CartDTO {

    Double totalAmount;
    Long customerId;
    List<Long> courseIdList;

    public CartDTO() {
    }

    public CartDTO(Double totalAmount, Long customerId, List<Long> courseIdList) {
        this.totalAmount = totalAmount;
        this.customerId = customerId;
        this.courseIdList = courseIdList;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public List<Long> getCourseIdList() {
        return courseIdList;
    }

    public void setCourseIdList(List<Long> courseIdList) {
        this.courseIdList = courseIdList;
    }

    @Override
    public String toString() {
        return "CartDTO [totalAmount=" + totalAmount + ", customerId=" + customerId + ", courseIdList=" + courseIdList
                + "]";
    }
    
}