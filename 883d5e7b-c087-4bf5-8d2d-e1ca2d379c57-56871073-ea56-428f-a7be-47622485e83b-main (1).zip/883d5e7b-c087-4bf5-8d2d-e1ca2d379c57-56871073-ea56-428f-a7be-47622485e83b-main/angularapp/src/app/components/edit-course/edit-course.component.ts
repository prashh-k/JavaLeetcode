import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Course } from 'src/app/models/course.model';
import { CourseService } from 'src/app/services/course.service';

@Component({
  selector: 'app-edit-course',
  templateUrl: './edit-course.component.html',
  styleUrls: ['./edit-course.component.css']
})
export class EditCourseComponent implements OnInit {

  courseId:string='';
  course:Course={};
  courses: string[] = [
    'Web Development', 'Mobile App Development', 'Data Science & Machine Learning', 'Cybersecurity','Artificial Inteligence(AI)', 'Finance & Accounting', 'Graphic Design', 'Marketing & Sales', 'Entrepreneurship', 'Networking', 'Communication Skills', 'Aptitude'
  ];
  constructor(private courseService:CourseService,
    private router:Router,
    private route:ActivatedRoute,
    private toastrService:ToastrService) { }

  ngOnInit(): void {
    this.courseId=this.route.snapshot.params['courseId'];
    this.courseService.getCourseById(this.courseId).subscribe((data)=>{
      this.course=data;
    })
  }
  
  updateCourse(){
    this.courseService.updateCourses(this.courseId,this.course).subscribe((data)=>{
      console.log(data);
      this.toastrService.success("course updated successfully");
      this.router.navigate(['/view-courses']);
    })

  }

}
