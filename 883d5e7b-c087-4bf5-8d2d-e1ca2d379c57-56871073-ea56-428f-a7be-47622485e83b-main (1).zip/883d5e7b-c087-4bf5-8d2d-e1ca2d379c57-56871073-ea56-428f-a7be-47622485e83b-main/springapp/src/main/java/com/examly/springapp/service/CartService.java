package com.examly.springapp.service;

import java.util.List;

import com.examly.springapp.DTO.CartDTO;
import com.examly.springapp.model.Cart;

public interface CartService {
    
    public Cart newCart(CartDTO cartDTO);
    public List<Cart>getAllCarts();
    public Cart getCartByCartId(Long cartId);
    public Cart editCart(Long cartId, CartDTO cartDTO);
    public Cart getCartByCustomerId(Long customerId);
    public Cart getCartByUserId(Long userId);
    public Cart addCourseToCart(Long userId, Long courseId);
    public Cart deleteCourseInCartByCourseId(Long cartId,Long courseId);
    public Long getCartIdByUserId(Long userId);
}