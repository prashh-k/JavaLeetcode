package com.examly.springapp.DTO;

import java.util.Date;

public class ReviewDTO {

    String subject;
    String body;
    int rating;
    Date dateCreated;
    Long customerId ;

    public ReviewDTO() {

    }

    public ReviewDTO(String subject, String body, int rating, Date dateCreated, Long customerId) {
        this.subject = subject;
        this.body = body;
        this.rating = rating;
        this.dateCreated = dateCreated;
        this.customerId = customerId;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    @Override
    public String toString() {
        return "reviewDTO [subject=" + subject + ", body=" + body + ", rating=" + rating + ", dateCreated="
                + dateCreated + ", customerId=" + customerId + "]";
    }

    
    

    
}
