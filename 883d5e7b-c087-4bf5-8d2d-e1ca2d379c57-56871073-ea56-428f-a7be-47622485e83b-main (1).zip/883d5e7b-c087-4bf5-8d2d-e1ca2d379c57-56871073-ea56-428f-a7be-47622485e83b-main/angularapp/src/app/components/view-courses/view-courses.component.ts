import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

import { imageUrl } from 'src/app/apiconfig';
import { CourseService } from 'src/app/services/course.service';

@Component({
  selector: 'app-view-courses',
  templateUrl: './view-courses.component.html',
  styleUrls: ['./view-courses.component.css']
})
export class ViewCoursesComponent implements OnInit {

  originalCourses: any[] = [];
  courses: any[] = [];
  url = imageUrl;
  searchTerm: string = '';
  category: string = '';
  order: string = 'asc';

  constructor(private courseService: CourseService,
    private route: Router,
    private toastrService: ToastrService) { }

  ngOnInit(): void {
    this.loadCourses();
  }

  loadCourses() {
    this.courseService.viewAllCourses().subscribe((data) => {
      console.log("load all courses:", data);
      this.originalCourses = data;
      this.courses = data;
    },

    )

  }


  deleteCourse(courseId): void {
    console.log("Course ID " + courseId);
    this.courseService.deleteCourse(courseId).subscribe((data) => {
      this.toastrService.success("course deleted successfully");
      this.loadCourses();
    },
      (error) => {
        this.toastrService.error("can't delete, course already brought my customer");
        // alert("can't delete course brought my someone");
      }
    );
  }

  editCourse(courseId: number) {
    this.route.navigate(['/edit-course/', courseId]);
  }
  
  searchCourse() {
    this.courses = this.originalCourses.filter(course => {
      return course.courseType.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
        course.courseDetails.toLowerCase().includes(this.searchTerm.toLowerCase());
    }).sort((c1,c2) =>{
      if(this.category === 'price'){
        return this.order === 'asc' ? c1.coursePrice - c2.coursePrice : c2.coursePrice - c1.coursePrice;
      }
      else if(this.category ==='coursename'){
        let comp = c1.courseDetails.toLowerCase().localeCompare(c2.courseDetails.toLowerCase());
        return this.order === 'asc' ? comp : -comp;
      }
      else
        return 0;
    })
  }
}

