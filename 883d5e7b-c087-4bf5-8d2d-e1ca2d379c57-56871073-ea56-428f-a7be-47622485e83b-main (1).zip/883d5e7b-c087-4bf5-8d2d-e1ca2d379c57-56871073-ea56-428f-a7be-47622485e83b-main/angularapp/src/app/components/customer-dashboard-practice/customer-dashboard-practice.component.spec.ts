import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerDashboardPracticeComponent } from './customer-dashboard-practice.component';

describe('CustomerDashboardPracticeComponent', () => {
  let component: CustomerDashboardPracticeComponent;
  let fixture: ComponentFixture<CustomerDashboardPracticeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerDashboardPracticeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerDashboardPracticeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
