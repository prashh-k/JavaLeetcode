package com.examly.springapp.DTO;

public class CustomerDTO {
    String customerName;
    String information;
    Long userId;
    public CustomerDTO() {
    }
    public CustomerDTO( String customerName, String information, long userId) {
        this.customerName = customerName;
        this.information = information;
        this.userId = userId;
    }
    
    public String getCustomerName() {
        return customerName;
    }
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
    public String getInformation() {
        return information;
    }
    public void setInformation(String information) {
        this.information = information;
    }
    public Long getUserId() {
        return userId;
    }
    public void setUserId(Long userId) {
        this.userId = userId;
    }
    @Override
    public String toString() {
        return "CustomerDTO [customerName=" + customerName + ", information="
                + information + ", userId=" + userId + "]";
    }

}
