package com.examly.springapp.DTO;


public class LoginResponseDTO {
    Long userId;
    String role ;
    Long cartId;
    String Token;
    public LoginResponseDTO() {
    }
    public LoginResponseDTO(Long userId, String role, Long cartId, String token) {
        this.userId = userId;
        this.role = role;
        this.cartId = cartId;
        Token = token;
    }
    public Long getUserId() {
        return userId;
    }
    public void setUserId(Long userId) {
        this.userId = userId;
    }
    
    public String getRole() {
        return role;
    }
    public void setRole(String role) {
        this.role = role;
    }
    public Long getCartId() {
        return cartId;
    }
    public void setCartId(Long cartId) {
        this.cartId = cartId;
    }
    public String getToken() {
        return Token;
    }
    public void setToken(String token) {
        Token = token;
    }  
    
}
