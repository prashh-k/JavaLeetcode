package com.examly.springapp.service;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.examly.springapp.model.Course;

@Service
public interface CourseService {
    // public Course addNewCourse(Course course);
    public Course addNewCourse(MultipartFile uploadFile, String courseType, String courseDetails, Double coursePrice)throws IOException;
    
    public List<Course> getAllCourses();
    public int editExistingCourse(String courseType, String courseDetails, Double coursePrice,Long courseId);
    public Course getCourseByCourseId(Long id);
    public boolean deleteCourseByCourseId(Long id);
}
