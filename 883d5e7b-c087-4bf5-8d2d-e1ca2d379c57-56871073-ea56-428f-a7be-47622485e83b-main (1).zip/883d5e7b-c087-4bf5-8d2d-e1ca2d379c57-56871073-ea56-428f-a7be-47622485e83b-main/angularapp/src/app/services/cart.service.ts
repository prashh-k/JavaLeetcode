import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { apiUrl } from '../apiconfig';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  constructor(private httpClient : HttpClient) { }

  addCart(newCart:any):Observable<any>{
    return this.httpClient.post<any>(`${apiUrl}/cart`, newCart);
  }

  getCartIdByUserId(userId):Observable<any>{
    return this.httpClient.get(`${apiUrl}/cart/getCartId/${userId}`);
  }

  getAllCoursesFromCart() : Observable<any>
  {
    return this.httpClient.get<any>(`${apiUrl}/cart`);
  }

  getCartByCartId(cartId:any):Observable<any>{
    return this.httpClient.get<any>(`${apiUrl}/cart/${cartId}`);
  }

  updateCart(cartId:any, cartDetails : any) : Observable<any>
  {
    return this.httpClient.put<any>(`${apiUrl}/cart/${cartId}`, cartDetails);
  }

  getCartByUserId(userId:any):Observable<any>{
    return this.httpClient.get<any>(`${apiUrl}/cart/user/${userId}`);
  }

  getCartByCustomerId(customerId:any):Observable<any>{
    return this.httpClient.get<any>(`${apiUrl}/cart/customer/${customerId}`);
  }

  addCourseToCart(cartId:any, courseId : any) : Observable<any>
  {
    return this.httpClient.put<any>(`${apiUrl}/cart/${cartId}/course/${courseId}`, {});
  }

  removeCoursesFromCart(cartId:any,courseId : any) : Observable<any>
  {
    return this.httpClient.delete<any>(`${apiUrl}/cart/${cartId}/course/${courseId}`);
  }

}