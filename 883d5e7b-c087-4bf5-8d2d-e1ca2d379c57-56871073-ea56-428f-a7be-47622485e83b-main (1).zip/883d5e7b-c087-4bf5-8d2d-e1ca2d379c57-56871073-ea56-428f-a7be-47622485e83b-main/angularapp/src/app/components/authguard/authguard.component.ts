import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-authguard',
  templateUrl: './authguard.component.html',
  styleUrls: ['./authguard.component.css']
})
export class AuthguardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
