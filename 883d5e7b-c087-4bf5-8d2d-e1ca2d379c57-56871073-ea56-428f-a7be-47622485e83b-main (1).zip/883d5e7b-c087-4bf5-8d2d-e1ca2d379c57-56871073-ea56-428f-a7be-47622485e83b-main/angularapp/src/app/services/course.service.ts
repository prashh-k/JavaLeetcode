import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { apiUrl } from '../apiconfig';


@Injectable({
  providedIn: 'root'
})

export class CourseService {

  constructor(private http: HttpClient) { }
  
  addCourse(formData): Observable<any> {
    return this.http.post(`${apiUrl}/course`, formData);
  }

  viewAllCourses(): Observable<any> {
    return this.http.get(`${apiUrl}/course`);
  }

  updateCourses(courseId: string, updatedCourse): Observable<any> {
    return this.http.put<any>(`${apiUrl}/course` + "/" + courseId, updatedCourse);
  }

  deleteCourse(courseId: number): Observable<any> {
    let str: string = `${apiUrl}/course` + "/" + courseId;
    console.log(str);
    return this.http.delete<any>(`${apiUrl}/course` + "/" + courseId);
  }

  getCourseById(courseId: string): Observable<any> {
    return this.http.get<any>(`${apiUrl}/course` + "/" + courseId);
  }


}

