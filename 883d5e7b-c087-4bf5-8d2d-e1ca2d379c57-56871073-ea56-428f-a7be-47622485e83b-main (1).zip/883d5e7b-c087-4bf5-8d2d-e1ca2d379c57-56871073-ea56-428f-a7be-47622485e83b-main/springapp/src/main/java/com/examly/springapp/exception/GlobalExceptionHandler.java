package com.examly.springapp.exception;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {


    @ExceptionHandler(PreexistingEmailException.class)
    public ResponseEntity<String> handlePreexistingEmailException(PreexistingEmailException pee)
    {
        return ResponseEntity.status(pee.getStatus()).body(pee.getMessage());
    }

    @ExceptionHandler(PreexistingMobileNumberException.class)
    public ResponseEntity<String> handlePreexistingMobileNumberException(PreexistingMobileNumberException pmn)
    {
        return ResponseEntity.status(pmn.getStatus()).body(pmn.getMessage());
    }

    @ExceptionHandler(PreexistingUsernameException.class)
    public ResponseEntity<String> handlePreexistingUsernameException(PreexistingUsernameException pue)
    {
        return ResponseEntity.status(pue.getStatus()).body(pue.getMessage());
    }

    @ExceptionHandler(InvalidPasswordException.class)
    public ResponseEntity<String> handleInvalidPasswordException(InvalidPasswordException ipe)
    {
        return ResponseEntity.status(ipe.getStatus()).body(ipe.getMessage());
    }
}
