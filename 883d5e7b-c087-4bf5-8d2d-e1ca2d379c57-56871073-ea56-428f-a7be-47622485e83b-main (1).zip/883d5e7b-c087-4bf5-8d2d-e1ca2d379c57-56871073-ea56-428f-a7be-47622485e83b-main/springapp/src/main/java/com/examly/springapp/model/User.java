package com.examly.springapp.model; 



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Transient;

@Entity
public class User {
    @Id
    @GeneratedValue
    private Long userId ;
    private String email ;
    private String password ;
    private String username ;
    private String mobileNumber ;
    private String role ;

    @Transient
    String Token;
    public User() {
    }
    public User(Long userId, String email, String password, String username, String mobileNumber, String role) {
        this.userId = userId;
        this.email = email;
        this.password = password;
        this.username = username;
        this.mobileNumber = mobileNumber;
        this.role = role;
    }
    public Long getUserId() {
        return userId;
    }
    public void setUserId(Long userId) {
        this.userId = userId;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getMobileNumber() {
        return mobileNumber;
    }
    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }
    public String getRole() {
        return role;
    }
    public void setRole(String role) {
        this.role = role;
    }
    public String getToken() {
        return Token;
    }
    public void setToken(String token) {
        Token = token;
    }
    @Override
    public String toString() {
        return "User [userId=" + userId + ", email=" + email + ", password=" + password + ", username=" + username
                + ", mobileNumber=" + mobileNumber + ", role=" + role + ", Token=" + Token + "]";
    }

    

    
    
}