
package com.examly.springapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.examly.springapp.model.Orders;

@Repository
public interface OrderRepo extends JpaRepository<Orders,Long>{
    List<Orders> findByCustomer_CustomerId(Long customerId);
    List<Orders> findByCustomer_User_UserId(Long userId);
}
