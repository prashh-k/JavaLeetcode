import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-dashboard-practice',
  templateUrl: './customer-dashboard-practice.component.html',
  styleUrls: ['./customer-dashboard-practice.component.css']
})
export class CustomerDashboardPracticeComponent implements OnInit {
  ngOnInit(): void {
  }

  questions = [
    {
      question: 'What is Spring Boot?',
      options: [
        'A framework for building web applications',
        'A tool for managing databases',
        'A framework for building stand-alone, production-grade Spring-based applications',
        'A library for handling HTTP requests'
      ],
      answer: 'A framework for building stand-alone, production-grade Spring-based applications'
    },
    {
      question: 'Which annotation is used to mark a Spring Boot application class?',
      options: [
        '@SpringBootApplication',
        '@EnableAutoConfiguration',
        '@ComponentScan',
        '@Configuration'
      ],
      answer: '@SpringBootApplication'
    },
    {
      question: 'What is the default embedded server used in Spring Boot?',
      options: [
        'Tomcat',
        'Jetty',
        'Undertow',
        'Netty'
      ],
      answer: 'Tomcat'
    },
    {
      question: 'Which property is used to configure the server port in a Spring Boot application?',
      options: [
        'server.port',
        'spring.port',
        'application.port',
        'server_port'
      ],
      answer: 'server.port'
    },
    {
      question: 'How do you enable scheduling in a Spring Boot application?',
      options: [
        '@EnableScheduling',
        '@EnableAsync',
        '@EnableSchedulingTasks',
        '@EnableTaskScheduling'
      ],
      answer: '@EnableScheduling'
    },
    {
      question: 'Which annotation is used to create a RESTful web service in Spring Boot?',
      options: [
        '@RestController',
        '@Controller',
        '@Service',
        '@Repository'
      ],
      answer: '@RestController'
    },
    {
      question: 'What is the purpose of the application.properties file in Spring Boot?',
      options: [
        'To configure application settings',
        'To store database credentials',
        'To define bean definitions',
        'To manage security settings'
      ],
      answer: 'To configure application settings'
    },
    {
      question: 'Which dependency is required to use Spring Data JPA in a Spring Boot application?',
      options: [
        'spring-boot-starter-data-jpa',
        'spring-boot-starter-web',
        'spring-boot-starter-security',
        'spring-boot-starter-thymeleaf'
      ],
      answer: 'spring-boot-starter-data-jpa'
    },
    {
      question: 'How do you run a Spring Boot application from the command line?',
      options: [
        'java -jar <application>.jar',
        'mvn spring-boot:run',
        'gradle bootRun',
        'All of the above'
      ],
      answer: 'All of the above'
    },
    {
      question: 'Which annotation is used to handle exceptions globally in a Spring Boot application?',
      options: [
        '@ControllerAdvice',
        '@ExceptionHandler',
        '@RestControllerAdvice',
        '@GlobalExceptionHandler'
      ],
      answer: '@ControllerAdvice'
    }
  ];

  currentQuestionIndex = 0;
  currentQuestion = this.questions[this.currentQuestionIndex];
  selectedOption: string = '';
  score = 0;
  quizStarted = false;
  quizCompleted = false;

  startQuiz() {
    this.quizStarted = true;
    this.quizCompleted = false;
    this.currentQuestionIndex = 0;
    this.currentQuestion = this.questions[this.currentQuestionIndex];
    this.score = 0;
    this.selectedOption = '';
  }

  selectOption(option: string) {
    this.selectedOption = option;
  }

  nextQuestion() {
    if (this.selectedOption === this.currentQuestion.answer) {
      this.score++;
    }
    this.currentQuestionIndex++;
    if (this.currentQuestionIndex < this.questions.length) {
      this.currentQuestion = this.questions[this.currentQuestionIndex];
      this.selectedOption = '';
    } else {
      this.quizCompleted = true;
      this.quizStarted = false;
    }
  }

  retakeQuiz() {
    this.startQuiz();
  }
}
