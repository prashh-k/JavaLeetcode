export interface Course{
    courseId?:number;
    courseType?:string;
    courseImageUrl?:string;
    courseDetails?:string;
    courseQuantity?:number;
    coursePrice?:number;
}