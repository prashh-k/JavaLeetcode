
package com.examly.springapp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.examly.springapp.DTO.OrdersDTO;
import com.examly.springapp.model.Orders;

@Service
public interface OrderService {

    Orders addOrder(OrdersDTO ordersDTO);

    List<Orders> getAll();

    Orders getOrderById(Long orderId);

    List<Orders> getOrderByCustomerId(Long customerId);

    boolean deleteOrder(Long orderId);

}
