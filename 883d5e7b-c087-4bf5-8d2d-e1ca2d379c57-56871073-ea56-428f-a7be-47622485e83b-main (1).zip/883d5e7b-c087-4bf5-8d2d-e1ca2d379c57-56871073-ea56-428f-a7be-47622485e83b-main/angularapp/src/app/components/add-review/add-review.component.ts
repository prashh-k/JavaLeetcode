import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/services/auth.service';
import { CustomerService } from 'src/app/services/customer.service';
import { OrderService } from 'src/app/services/order.service';
import { ReviewService } from 'src/app/services/review.service';

@Component({
  selector: 'app-add-review',
  templateUrl: './add-review.component.html',
  styleUrls: ['./add-review.component.css']
})
export class AddReviewComponent implements OnInit {
  courses: any[] = [];
  review: any;
  reviewForm: FormGroup;
  customerId: number;
  courseTypes: any[] = [];
  constructor(private reviewService: ReviewService,
    private fb: FormBuilder, private router: Router,
    private customerService: CustomerService,
    private authService: AuthService,
    private orderService: OrderService,
    private toastrService: ToastrService) {
    this.reviewForm = this.fb.group({
      //customerId: [null, Validators.required],
      subject: ['', Validators.required],
      body: ['', Validators.required],
      rating: ['', Validators.required]
    });
  }


  ngOnInit(): void {
    this.loadOrdersByUserId();
  }

  loadOrdersByUserId() {
    if (this.authService.getCartId() && parseInt(this.authService.getCartId()) !== -1)
      this.orderService.viewOrderByUserId(this.authService.getAuthenticatedUserId()).subscribe(data => {
        for (let order of data) {
          for (let course of order.courses) {
            // console.log(course);
            this.courses.push(course);
          }
        }

      });
  }

  addReview() {
    if (this.reviewForm.valid) {
      this.customerService.viewCustomerByUserId(this.authService.getAuthenticatedUserId()).subscribe((data) => {
        console.log(data);
        this.review = this.reviewForm.value;
        this.review.dateCreated = new Date();
        this.review.customerId = data.customerId;
        console.log(this.review);
        this.reviewService.addReview(this.review).subscribe((data) => {
          console.log(data);
          this.toastrService.success("review added");
          this.router.navigate(['/view-review']);
        });
      });

    }
  }


  get f() {
    return this.reviewForm.controls;
  }

  getCartId() {
    return parseInt(this.authService.getCartId());
  }
}
