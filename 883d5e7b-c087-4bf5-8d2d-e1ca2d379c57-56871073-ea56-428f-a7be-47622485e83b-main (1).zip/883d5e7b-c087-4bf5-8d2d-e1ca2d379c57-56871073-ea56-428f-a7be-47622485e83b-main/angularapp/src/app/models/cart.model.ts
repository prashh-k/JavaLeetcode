export interface Cart
{
    cartId ?: number;
    customerId ?: number;
    courseId ?: number[];
    totalAmount?:number;
}