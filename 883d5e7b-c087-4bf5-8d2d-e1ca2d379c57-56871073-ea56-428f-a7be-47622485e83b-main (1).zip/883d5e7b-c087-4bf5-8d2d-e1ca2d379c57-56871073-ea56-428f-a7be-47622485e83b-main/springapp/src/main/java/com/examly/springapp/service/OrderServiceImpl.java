
package com.examly.springapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.DTO.OrdersDTO;
import com.examly.springapp.model.Course;
import com.examly.springapp.model.Orders;
import com.examly.springapp.repository.CourseRepo;
import com.examly.springapp.repository.CustomerRepo;
import com.examly.springapp.repository.OrderRepo;

@Service
public class OrderServiceImpl implements OrderService {
    OrderRepo orderRepo;
    CourseRepo courseRepo;
    CustomerRepo customerRepo;

    @Autowired
    public OrderServiceImpl(OrderRepo orderRepo,CourseRepo courseRepo,CustomerRepo customerRepo) {
        this.orderRepo = orderRepo;
        this.courseRepo = courseRepo;
        this.customerRepo = customerRepo;
    }

    @Override
    public Orders addOrder(OrdersDTO orderDTO) {
        Orders order = new Orders();

        List<Course> courses = new ArrayList<>();
        for(Long courseId : orderDTO.getCourseIdList()){
            courses.add(courseRepo.findById(courseId).get());
        }

        order.setOrderPrice(orderDTO.getOrderPrice());
        order.setCourses(courses);
        order.setCustomer(customerRepo.findById(orderDTO.getCustomerId()).get());

        return this.orderRepo.save(order);
    }

    @Override
    public List<Orders> getAll() {
        return orderRepo.findAll();
    }

    @Override
    public Orders getOrderById(Long orderId) {
        Optional<Orders> optOrder = orderRepo.findById(orderId);
        if (optOrder.isPresent()) {
            return optOrder.get();
        }
        return null;
    }

    @Override
    public List<Orders> getOrderByCustomerId(Long customerId) {
        List<Orders> optCustomer = orderRepo.findByCustomer_CustomerId(customerId);
        if (optCustomer != null) {
            return optCustomer;
        }
        return null;
    }

    public List<Orders> getOrderByUserId(Long userId) {
        List<Orders> newOrder = orderRepo.findByCustomer_User_UserId(userId);
        if (newOrder != null) {
            return newOrder;
        }
        return null;
    }

    @Override
    public boolean deleteOrder(Long orderId) {
        Optional<Orders> optOrder=orderRepo.findById(orderId);
        if (optOrder.isPresent()) {
            orderRepo.delete(optOrder.get());
            return true;
        }
        return false;
    }
}
