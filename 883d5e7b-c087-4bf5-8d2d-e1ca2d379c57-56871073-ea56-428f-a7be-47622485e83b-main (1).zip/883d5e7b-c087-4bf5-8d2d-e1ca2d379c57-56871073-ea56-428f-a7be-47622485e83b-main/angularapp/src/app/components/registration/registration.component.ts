import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/services/auth.service';
 
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
 
  registrationForm: FormGroup;

  showPassword: boolean = false;
  showConfirmPassword: boolean = false;


 
  constructor(private authService: AuthService,
    private formBuilder: FormBuilder,
    private router: Router,
    private toastrService:ToastrService) {
    this.registrationForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)]],
      confirmPassword: ['', Validators.required],
      username: ['', [Validators.required, Validators.pattern(/^[a-zA-Z0-9_]{3,10}$/)]],
      mobileNumber: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      role: [''],
      terms: [false, Validators.requiredTrue]  // Add the checkbox control here
    }, { validator: this.mustMatch('password', 'confirmPassword') });
  }
 
  ngOnInit(): void {}
 
  register() {
    console.log(this.registrationForm.value);
    this.authService.register(this.registrationForm.value).subscribe(
      (data) => {
        // alert("registration done");
        this.toastrService.success("registration done");
        this.router.navigate(['/login']);
      },
      error => {
        this.toastrService.error(JSON.stringify(error['error']));
        // window.alert(JSON.stringify(error['error']));
      }
    );
  }
 
  get f() {
    return this.registrationForm.controls;
  }
 
  mustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
      const matchingControl = formGroup.controls[matchingControlName];
      if (matchingControl.errors && !matchingControl.errors['mustMatch']) {
        return;
      }
      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ mustMatch: true });
      } else {
        matchingControl.setErrors(null);
      }
    };
  }
 
  checkbox: boolean = false;
 
  toggleCheckbox() {
    this.checkbox = !this.checkbox;
  }

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  toggleConfirmPasswordVisibility() {
    this.showConfirmPassword = !this.showConfirmPassword;
  }


}
 