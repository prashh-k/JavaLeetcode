import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { imageUrl } from 'src/app/apiconfig';
import { Course } from 'src/app/models/course.model';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { CartService } from 'src/app/services/cart.service';
import { CourseService } from 'src/app/services/course.service';
import { CustomerService } from 'src/app/services/customer.service';
import { OrderService } from 'src/app/services/order.service';

@Component({
  selector: 'app-customer-view-courses',
  templateUrl: './customer-view-courses.component.html',
  styleUrls: ['./customer-view-courses.component.css']
})
export class CustomerViewCoursesComponent implements OnInit {

  // makePaymentForm: FormGroup;
  courses: Course[] = [];
  myCourses: any[] = [];
  myOrders: any[] = [];
  originalCourses: any[] = [];
  userId: number;
  imgUrl = imageUrl;
  selectedCourse: any;
  cart: any;
  user: User;
  cartId: number;
  customerId: number;
  searchTerm: string = '';
  category: string = '';
  order: string = 'asc';

  constructor(private courseService: CourseService,
    private router: Router, private cartService: CartService, private authService: AuthService,
    private customerService: CustomerService, private orderService: OrderService,
    private toastrService: ToastrService) { }

  ngOnInit(): void {
    this.userId = this.authService.getAuthenticatedUserId();
    this.viewAllCourses();
    this.loadCoursesAndCart();
  }

  loadCoursesAndCart() {
    
    if (this.authService.getCartId() && parseInt(this.authService.getCartId()) !== -1) {

      this.orderService.viewOrderByUserId(this.authService.getAuthenticatedUserId()).subscribe((data) => {
        this.myOrders = data;
        for (let order of this.myOrders) {
          for (let course of order.courses) {
            this.myCourses.push(course);
          }
        }
      });


      this.cartService.getCartByCartId(this.authService.getCartId()).subscribe((data) => {
        this.cart = data;
      });
    }
  }

  viewAllCourses() {
    this.courseService.viewAllCourses().subscribe((data) => {
      this.originalCourses = data;
      this.courses = data;
    });
  }

  addToCart(course) {
    if (this.authService.isUserLoggedIn()) {
      this.cartId = parseInt(this.authService.getCartId());
      if (this.cartId === -1) {
        let newCustomer = {
          customerName: this.authService.getAuthenticatedUser(),
          information: "student",
          userId: this.userId
        }
        this.customerService.registerCustomer(newCustomer).subscribe((data) => {
          this.customerId = data.customerId;
          let newCart = {
            customerId: this.customerId,
            courseIdList: [course.courseId],
            totalAmount: course.coursePrice
          }
          this.cartService.addCart(newCart).subscribe((data) => {
            this.authService.setCartId(data.cartId);
            this.cartId = data.cartId;
          });
        });
      }
      else {

        if (parseInt(this.authService.getCartId()) !== -1) {
          for (let cartCourse of this.cart.courses) {
            if (course.courseId === cartCourse.courseId) {
              this.toastrService.warning("Course already in cart");
              // alert("Course already in cart");
              return;
            }
          }
        }
        this.cartService.addCourseToCart(this.cartId, course.courseId).subscribe((data) => { });
      }

      this.toastrService.success("course added to cart");
      this.router.navigate(['/my-cart']);
    }

    else {
      this.router.navigate(['/login']);
    }
  }

  isBought(course) {

    for (let mycourse of this.myCourses) {
      if (course.courseId === mycourse.courseId) {
        return true;
      }
    }
    return false;
  }

  searchCourse() {
    this.courses = this.originalCourses.filter(course => {
      return course.courseType.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
        course.courseDetails.toLowerCase().includes(this.searchTerm.toLowerCase());
    }).sort((c1,c2) =>{
      if(this.category === 'price'){
        return this.order === 'asc' ? c1.coursePrice - c2.coursePrice : c2.coursePrice - c1.coursePrice;
      }
      else if(this.category ==='coursename'){
        let comp = c1.courseDetails.toLowerCase().localeCompare(c2.courseDetails.toLowerCase());
        return this.order === 'asc' ? comp : -comp;
      }
      else
        return 0;
    })
  }
}




