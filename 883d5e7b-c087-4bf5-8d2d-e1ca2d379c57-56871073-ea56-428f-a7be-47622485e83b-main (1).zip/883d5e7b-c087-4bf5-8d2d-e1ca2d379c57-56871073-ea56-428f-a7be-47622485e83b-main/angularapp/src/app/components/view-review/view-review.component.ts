import { Component, OnInit, ɵɵpipeBind1 } from '@angular/core';
import { Review } from 'src/app/models/review.model';
import { ReviewService } from 'src/app/services/review.service';

@Component({
  selector: 'app-view-review',
  templateUrl: './view-review.component.html',
  styleUrls: ['./view-review.component.css']
})
export class ViewReviewComponent implements OnInit {
  originalReviews = [];
  reviews: any[] = [];
  termButton: string = '';
  category: string = '';
  order: string = "asc";
  constructor(private reviewService: ReviewService) { }

  ngOnInit(): void {
    this.getAllReviews();
  }

  getAllReviews() {
    this.reviewService.getAllReviews().subscribe((data: Review[]) => {
      console.log(data);
      this.originalReviews = data;
      this.reviews = data;
    });
  }

  searchFilter() {
    this.reviews = this.originalReviews.filter(rev => {
      return rev.body.toLowerCase().includes(this.termButton.toLowerCase()) ||
        rev.subject.toLowerCase().includes(this.termButton.toLowerCase());
    })
      .sort((c1, c2) => {
        if (this.category === 'dateCreated') {

          const date1 = new Date(c1.dateCreated).getTime();
          const date2 = new Date(c2.dateCreated).getTime();

          return this.order === 'asc' ? date1 - date2 : date2 - date1;
        }
        else if (this.category === 'subject') {
          const subject1 = c1.subject.toLowerCase();
          const subject2 = c2.subject.toLowerCase();
          return this.order === 'asc' ? subject1.localeCompare(subject2) : subject2.localeCompare(subject1);
        }
        else
          return 0;

      });
  }

}

