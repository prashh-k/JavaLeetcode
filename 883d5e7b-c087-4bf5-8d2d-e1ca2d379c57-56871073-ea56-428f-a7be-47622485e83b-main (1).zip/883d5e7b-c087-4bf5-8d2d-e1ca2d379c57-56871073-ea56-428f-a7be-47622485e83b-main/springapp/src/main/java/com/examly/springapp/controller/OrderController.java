
package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.DTO.OrdersDTO;
import com.examly.springapp.model.Orders;
import com.examly.springapp.service.CustomerServiceImpl;
import com.examly.springapp.service.OrderServiceImpl;

@RestController
@RequestMapping("/api/order")
public class OrderController {
    OrderServiceImpl orderServiceImpl;
    CustomerServiceImpl customerServiceImpl;

    @Autowired
    public OrderController(OrderServiceImpl orderServiceImpl, CustomerServiceImpl customerServiceImpl) {
        this.orderServiceImpl = orderServiceImpl;
        this.customerServiceImpl = customerServiceImpl;
    }

    @PostMapping
    public ResponseEntity<Orders> createOrder(@RequestBody OrdersDTO orderDTO) {
        Orders orders = orderServiceImpl.addOrder(orderDTO);
        if (orders != null) {
            return ResponseEntity.status(201).body(orders);
        } else {
            return ResponseEntity.status(500).build();
        }
    }

    @GetMapping
    public ResponseEntity<List<Orders>> getAll() {
        List<Orders> orders = orderServiceImpl.getAll();
        if (!orders.isEmpty()) {
            return ResponseEntity.status(200).body(orders);
        } else {
            return ResponseEntity.status(404).build();
        }
    }

    @GetMapping("/{orderId}")
    public ResponseEntity<Orders> getOrderById(@PathVariable Long orderId) {
        Orders orders = orderServiceImpl.getOrderById(orderId);
        if (orders != null) {
            return ResponseEntity.status(200).body(orders);
        } else {
            return ResponseEntity.status(404).build();
        }
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<Orders>> getOrderByCustomerId(@PathVariable Long customerId) {
        System.out.println("in order controller customer fun"+customerId);
        List<Orders> orders = orderServiceImpl.getOrderByCustomerId(customerId);
        if (!orders.isEmpty()) {
            return ResponseEntity.status(200).body(orders);
        } else {
            return ResponseEntity.status(404).build();
        }
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Orders>> getOrderByUserrId(@PathVariable Long userId) {
        List<Orders> orders = orderServiceImpl.getOrderByUserId(userId);
        if (!orders.isEmpty()) {
            return ResponseEntity.status(200).body(orders);
        } else {
            return ResponseEntity.status(404).build();
        }
    }

    @DeleteMapping("/{orderId}")
    public ResponseEntity<Boolean> delete(@PathVariable Long orderId) {
        boolean orders = orderServiceImpl.deleteOrder(orderId);
        if (orders) {
            return ResponseEntity.status(200).body(orders);
        } else {
            return ResponseEntity.status(500).build();
        }
    }

}
