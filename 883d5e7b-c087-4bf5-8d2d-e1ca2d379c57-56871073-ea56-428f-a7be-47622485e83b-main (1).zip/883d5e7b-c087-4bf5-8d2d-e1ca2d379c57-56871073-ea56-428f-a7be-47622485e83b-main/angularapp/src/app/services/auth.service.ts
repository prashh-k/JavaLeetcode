import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../models/user.model';
import { Observable, BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { apiUrl } from '../apiconfig';
 
export const AUTHENTICATED_USER = 'authenticatedUser';
export const TOKEN = 'token';
export const PAGE_ID = 'pageId';
export const ROLE = 'role';
export const USER_ID = 'userId';
export const CART_ID = 'cartId';
 
export class AuthenticationBean {
  constructor(
    public userId: number,
    public token: string,
    public role: string,
    public cartId: number
  ) { }
}
 
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private authenticatedUserSubject = new BehaviorSubject<string | null>(null);
  authenticatedUser$ = this.authenticatedUserSubject.asObservable();
 
  constructor(private http: HttpClient) {
    const user = sessionStorage.getItem(AUTHENTICATED_USER);
    if (user) {
      this.authenticatedUserSubject.next(user);
    }
  }
 
  register(user: User): Observable<any> {
    return this.http.post(`${apiUrl}/register`, user);
  }
 
  executeAuthencationService(username: string, password: string): Observable<AuthenticationBean> {
    return this.http.post<AuthenticationBean>(`${apiUrl}/login`, { username, password }).pipe(
      map(data => {
        console.log(data);
        sessionStorage.setItem(USER_ID, "" + data.userId);
        sessionStorage.setItem(AUTHENTICATED_USER, username);
        sessionStorage.setItem(ROLE, "" + data.role);
        sessionStorage.setItem(CART_ID, "" + data.cartId);
        sessionStorage.setItem(TOKEN, `Bearer ${data.token}`);
        this.authenticatedUserSubject.next(username);
        return data;
      })
    );
  }

  getUserByUserId(userId):Observable<any>{
    return this.http.get(`${apiUrl}/user/${userId}`);
  }
 
  getAuthenticatedUserId(): number {
    return parseInt(sessionStorage.getItem(USER_ID));
  }
 
  getAuthenticatedUser(): string | null {
    return this.authenticatedUserSubject.value;
  }
 
  getUserRole(): string | null {
    return sessionStorage.getItem(ROLE);
  }
 
  getAuthenticatedToken(): string | null {
    if (this.getAuthenticatedUser()) {
      return sessionStorage.getItem(TOKEN);
    }
    return null;
  }
 
  getCartId(): string | null {
    return sessionStorage.getItem(CART_ID);
  }
 
  setCartId(cartId: string): void {
    sessionStorage.setItem(CART_ID, cartId);
  }
 
  isAdmin(): boolean {
    let role = sessionStorage.getItem(ROLE);
    return role === 'Admin';
  }
 
  isUser(): boolean {
    let role = sessionStorage.getItem(ROLE);
    return role === 'User';
  }
 
  isUserLoggedIn(): boolean {
    return !!this.authenticatedUserSubject.value;
  }
 
  logout(): void {
    sessionStorage.removeItem(AUTHENTICATED_USER);
    sessionStorage.removeItem(TOKEN);
    sessionStorage.removeItem(PAGE_ID);
    sessionStorage.removeItem(ROLE);
    sessionStorage.removeItem(USER_ID);
    this.authenticatedUserSubject.next(null);
  }
 
  pageId(): string {
    var pageId = sessionStorage.getItem(PAGE_ID);
    if (pageId === null) {
      sessionStorage.setItem(PAGE_ID, 'login');
    }
    return pageId;
  }
 
  setPageId(pageId: string): void {
    sessionStorage.setItem(PAGE_ID, pageId);
  }
}

