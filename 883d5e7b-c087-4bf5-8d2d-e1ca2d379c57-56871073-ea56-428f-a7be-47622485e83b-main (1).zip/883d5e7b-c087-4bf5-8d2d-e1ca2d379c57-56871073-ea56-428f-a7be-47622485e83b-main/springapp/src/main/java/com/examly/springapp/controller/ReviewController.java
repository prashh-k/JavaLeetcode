package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.DTO.ReviewDTO;
import com.examly.springapp.model.Review;
import com.examly.springapp.service.ReviewServiceImpl;

@RestController
@RequestMapping("/api/review")
public class ReviewController {

    @Autowired
    ReviewServiceImpl reviewServiceImpl;
 
    @PostMapping
    public ResponseEntity<Review> createReview(@RequestBody ReviewDTO reviewDto)
    {
        Review rev = reviewServiceImpl.createReview(reviewDto);
        if(rev == null)
            return ResponseEntity.status(500).build();
        return ResponseEntity.status(201).body(rev);
    }

    @GetMapping
    public ResponseEntity<List<Review>> getAllReviews()
    {
        List<Review> listReview = reviewServiceImpl.getAllReviews();
        if(listReview.isEmpty())
            return ResponseEntity.status(404).build();
        return ResponseEntity.status(200).body(listReview);
    }

    @GetMapping("/{reviewId}")
    public ResponseEntity<Review> getReviewById(@PathVariable long reviewId)
    {
        Review rev = reviewServiceImpl.getReviewById(reviewId);
        if(rev == null)
            return ResponseEntity.status(404).build();
        return ResponseEntity.status(200).body(rev);
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Review>> findByUserId(@PathVariable long userId)
    {
       List<Review> listReview = reviewServiceImpl.findByUserId(userId);
       if(listReview.isEmpty())
            return ResponseEntity.status(404).build();
        return ResponseEntity.status(200).body(listReview);
    }

    // @DeleteMapping("/{reviewId}")
    // public ResponseEntity<Boolean> deleteReviewById(@PathVariable long reviewId)
    // {
    //     if(!(reviewServiceImpl.deleteReviewById(reviewId)))
    //         return ResponseEntity.status(500).body(false);
    //     return ResponseEntity.status(200).body(true);
    // }
}
