import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ChartsModule } from 'ng2-charts';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { AddCourseComponent } from './components/add-course/add-course.component';
import { AddReviewComponent } from './components/add-review/add-review.component';
import { AuthguardComponent } from './components/authguard/authguard.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { CustomerDashboardCoursesComponent } from './components/customer-dashboard-courses/customer-dashboard-courses.component';
import { CustomerDashboardPracticeComponent } from './components/customer-dashboard-practice/customer-dashboard-practice.component';
import { CustomerViewCoursesComponent } from './components/customer-view-courses/customer-view-courses.component';
import { CustomerdashboardComponent } from './components/customerdashboard/customerdashboard.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { EditCourseComponent } from './components/edit-course/edit-course.component';
import { ErrorComponent } from './components/error/error.component';
import { FooterComponent } from './components/footer/footer.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { MyCartComponent } from './components/my-cart/my-cart.component';
import { MyOrdersComponent } from './components/my-orders/my-orders.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { PlaceOrderComponent } from './components/place-order/place-order.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { ViewCoursesComponent } from './components/view-courses/view-courses.component';
import { ViewOrdersComponent } from './components/view-orders/view-orders.component';
import { ViewReviewComponent } from './components/view-review/view-review.component';
import { HttpIntercepterBasicAuthService } from './services/http-intercepter-basic-auth.service';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CurrencyPipe } from '@angular/common';



@NgModule({
  declarations: [
    AppComponent,
    AddCourseComponent,
    AddReviewComponent,
    AuthguardComponent,
    CustomerViewCoursesComponent,
    CustomerdashboardComponent,
    DashboardComponent,
    EditCourseComponent,
    ErrorComponent,
    HomeComponent,
    LoginComponent,
    MyCartComponent,
    MyOrdersComponent,
    NavbarComponent,
    PlaceOrderComponent,
    RegistrationComponent,
    ViewCoursesComponent,
    ViewOrdersComponent,
    ViewReviewComponent,
    FooterComponent,
    ContactUsComponent,
    AboutUsComponent,
    CustomerDashboardCoursesComponent,
    CustomerDashboardPracticeComponent

  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule,
    BrowserModule,
    AppRoutingModule,
    ChartsModule,
    ToastrModule.forRoot({
      timeOut: 3000,
      positionClass: 'toast-top-right',
      preventDuplicates: true,
      progressBar:true,
      closeButton: false,
      enableHtml:true,
    }),
    BrowserAnimationsModule,
    BrowserModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpIntercepterBasicAuthService,
      multi: true
    },
    CurrencyPipe
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }