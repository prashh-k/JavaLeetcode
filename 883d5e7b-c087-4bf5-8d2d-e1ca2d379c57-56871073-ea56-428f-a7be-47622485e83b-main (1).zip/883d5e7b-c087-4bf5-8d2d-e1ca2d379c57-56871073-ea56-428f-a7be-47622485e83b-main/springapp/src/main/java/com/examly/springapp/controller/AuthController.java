package com.examly.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.DTO.LoginResponseDTO;
import com.examly.springapp.model.LoginDTO;
import com.examly.springapp.model.User;
import com.examly.springapp.service.UserServiceImpl;

@RestController
@RequestMapping("/api")
public class AuthController {

    UserServiceImpl userService ;
    
    @Autowired
    public AuthController(UserServiceImpl userService) {
        this.userService = userService ;
    }

    @PostMapping("/register") 
    public ResponseEntity<User> registerUser(@RequestBody User user) {
        User newUser =  userService.register(user);
        if(newUser != null) {
            return ResponseEntity.status(200).body(newUser);
        }
        return ResponseEntity.status(500).build();
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponseDTO> loginUser(@RequestBody LoginDTO loginDTO) {
        System.out.println(loginDTO);
        LoginResponseDTO newUser =  userService.login(loginDTO);
        if(newUser != null) {
            return ResponseEntity.status(201).body(newUser);
        }
        return ResponseEntity.status(500).build();

    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<User> getUserByUserId(@PathVariable Long userId){
        User newUser = userService.getUserByUserId(userId);
        if(newUser != null){
            return ResponseEntity.status(200).body(newUser);
        }
        return ResponseEntity.status(404).build();
    }

    @GetMapping("/confi")
    public String configuration(){
        return "this is point need authentication";
    }
    
    @GetMapping("/hello")
    public String hello(){
        return "Hello world this is a open end point";
    }
    
    

}
