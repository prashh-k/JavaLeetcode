package com.examly.springapp.model;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;


@Entity
public class Review {
    @Id
    @GeneratedValue
    protected long reviewId;
    protected String subject;
    protected String body;
    protected int rating;
    protected Date dateCreated;
    
    @OneToOne
    Customer customer;

    public Review() {
    }

    public Review(long reviewId, String subject, String body, int rating, Date dateCreated, Customer customer) {
        this.reviewId = reviewId;
        this.subject = subject;
        this.body = body;
        this.rating = rating;
        this.dateCreated = dateCreated;
        this.customer = customer;
    }

    public long getReviewId() {
        return reviewId;
    }

    public void setReviewId(long reviewId) {
        this.reviewId = reviewId;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @Override
    public String toString() {
        return "Review [reviewId=" + reviewId + ", subject=" + subject + ", body=" + body + ", rating=" + rating
                + ", dateCreated=" + dateCreated + ", customer=" + customer + "]";
    }

    
}
