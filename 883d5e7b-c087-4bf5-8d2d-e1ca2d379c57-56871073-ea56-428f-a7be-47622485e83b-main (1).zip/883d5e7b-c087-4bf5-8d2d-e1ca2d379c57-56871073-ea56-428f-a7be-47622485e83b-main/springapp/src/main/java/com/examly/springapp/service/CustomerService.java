package com.examly.springapp.service;

import java.util.List;

import com.examly.springapp.DTO.CustomerDTO;
import com.examly.springapp.model.Customer;

public interface CustomerService {
  
    public Customer addNewCustomer(CustomerDTO customerDTO);
    public Customer getCustomerByCustomerId(Long customerId);
    public Customer getCustomerByUserId(Long userId);
    public List<Customer> getAllCustomers();
}
