import { Component, OnInit } from '@angular/core';
import { imageUrl } from 'src/app/apiconfig';
import { Order } from 'src/app/models/order.model';
import { AuthService } from 'src/app/services/auth.service';
import { OrderService } from 'src/app/services/order.service';

@Component({
  selector: 'app-customer-dashboard-courses',
  templateUrl: './customer-dashboard-courses.component.html',
  styleUrls: ['./customer-dashboard-courses.component.css']
})
export class CustomerDashboardCoursesComponent implements OnInit {
  url = imageUrl;
  coursesIds: string[] = [];
  myOrders: any[] = [];
  myCourses: any[] = [];
  customerId: number;
  constructor(private orderService: OrderService,
    private authService: AuthService) { }

  ngOnInit(): void {
    this.loadOrders();
  }

  loadOrders() {

    if (this.authService.getCartId() && parseInt(this.authService.getCartId()) !== -1) {

      this.orderService.viewOrderByUserId(this.authService.getAuthenticatedUserId()).subscribe((data) => {
        this.myOrders = data;
        for (let order of this.myOrders) {
          console.log("in orders loop");
          for (let course of order.courses) {
            console.log("in course loop");
            this.myCourses.push(course);
          }
        }
        console.log('myCourses:', this.myCourses);
      });
    }
  }


}
