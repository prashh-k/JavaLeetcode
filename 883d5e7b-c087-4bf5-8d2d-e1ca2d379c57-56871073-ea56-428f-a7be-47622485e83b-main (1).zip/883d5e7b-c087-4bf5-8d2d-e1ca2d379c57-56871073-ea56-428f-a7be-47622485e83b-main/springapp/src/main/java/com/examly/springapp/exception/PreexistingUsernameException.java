package com.examly.springapp.exception;

public class PreexistingUsernameException extends RuntimeException {

    int status;

    public PreexistingUsernameException(String message, int status) {
        super(message);
        this.status = status;
    }

    public int getStatus()
    {
        return status;
    }
}