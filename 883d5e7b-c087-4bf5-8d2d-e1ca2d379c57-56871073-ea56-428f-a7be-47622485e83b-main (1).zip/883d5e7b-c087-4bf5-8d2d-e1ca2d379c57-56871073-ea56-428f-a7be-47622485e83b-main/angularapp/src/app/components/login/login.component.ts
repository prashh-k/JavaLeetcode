import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/services/auth.service';
import { CartService } from 'src/app/services/cart.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  showPassword: boolean = false;

  constructor(private auth: AuthService,
    private formBuilder: FormBuilder,
    private router: Router,
    private cartService: CartService,
    private toastrService:ToastrService) {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  ngOnInit(): void { }

  login() {
    this.auth.executeAuthencationService(this.loginForm.value.username, this.loginForm.value.password).subscribe(data => {
      this.toastrService.success("Login successful");
      this.router.navigate(['/']);

    },
      error => {
        console.log(error);
        this.toastrService.error("Invalid Credentials");
        // window.alert("Username Not Found.");
      });
  }
  

  intializeCartId(userId: number) {
    this.cartService.getCartIdByUserId(userId).subscribe(data => {
      console.log("from login component", data);
    });
  }

  get f() {
    return this.loginForm.controls;
  }

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }
}
