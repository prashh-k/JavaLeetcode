package com.examly.springapp.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.DTO.ReviewDTO;
import com.examly.springapp.model.Review;
import com.examly.springapp.repository.CustomerRepo;
import com.examly.springapp.repository.ReviewRepo;

@Service
public class ReviewServiceImpl implements ReviewService {
    ReviewRepo reviewRepo;
    CustomerRepo customerRepo;

    @Autowired
    public ReviewServiceImpl(ReviewRepo reviewRepo,CustomerRepo customerRepo) {
        this.reviewRepo = reviewRepo;
        this.customerRepo = customerRepo;
    }

    public Review createReview(ReviewDTO reviewDTO)
    {
        Review review = new Review();
        review.setSubject(reviewDTO.getSubject());
        review.setBody(reviewDTO.getBody());
        review.setRating(reviewDTO.getRating());
        review.setDateCreated(reviewDTO.getDateCreated());
        review.setCustomer(customerRepo.findById(reviewDTO.getCustomerId()).get());
        return reviewRepo.save(review);
    }

    public List<Review> getAllReviews()
    {
        return reviewRepo.findAll();
    }

    public Review getReviewById(long reviewId)
    {
        Optional<Review> optReview = reviewRepo.findById(reviewId);
        if(optReview.isPresent())
        {
            return optReview.get();
        }
        return null;
    }

    // public boolean deleteReviewById(long reviewId)
    // {
    //     Optional<Review> optReview = reviewRepo.findById(reviewId);
    //     if(optReview.isPresent())
    //     {
    //         reviewRepo.delete(optReview.get());
    //         return true;
    //     }
    //     return false;
    // }

    public List<Review> findByUserId(long userId)
    {
        return reviewRepo.findByUserId(userId);
    }
}
